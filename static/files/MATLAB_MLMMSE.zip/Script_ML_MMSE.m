% Script - Demonstration of the sources' ML-based MMSE estimate MATALB package
% In this example, we consider the estimation and separation of three AR(1) sources
%
% Other m-files required: Compute_sources_ML_MMSE_estimate.m
% Subfunctions: none
% MAT-files required: none
%
% Based on the paper:
%			 "A Maximum Likelihood-Based Minimum Mean Square Error Separation and Estimation
%			 of Stationary Gaussian Sources from Noisy Mixtures", Amir Weiss and Arie Yeredor,
%			 submitted of IEEE Trans. on Signal Processing , August 2018.
%
% See also: readmeMLMMSE.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

clear; clc;

% Set values of related parameters
M = 3;   % number of sources
L = 4;   % number of sensors
T = 1e3; % samples size
% draw AR(1) parameters from the range [0.1,0.9] with 
a1 = (2*randi(2,1,M)-3).*(0.1+0.8*rand(1,M));

% Compute the autocorrelation sequence
C_s = zeros(M,T);
norm_coef = zeros(1,M);
for m=1:M
    norm_coef(m) = 1/(1-a1(m)^2); % normalization factor
    C_s(m,:) = (-a1(m)).^(abs((1:T)-T/2-1)); % autocorrelation sequence of the m-th source
end

% Fix the mixing matrix and noise variances
% Note: In this particular example, the elements of A are iid nrormal,
% and the variances of the noise are iid uniform from the range [0,0.1].
% Of course, this is just an arbitrary choise and it may be changed.
A = randn(L,M); % 
lambda = 0.1*rand(L,1); %

% Generate the sources
S = zeros(M,T);
for m=1:M
    s_m_raw = filter(1,[1 a1(m)],randn(1,2*T));
    S(m,:) = (1/sqrt(norm_coef(m)))*s_m_raw(T+1:end); % normalize to get unit variance
end
        
% Generate noisy mixtures
V = sqrt(repmat(lambda,1,T)).*randn(L,T); % draw temporally-white gaussian noise porcesses
X = A*S + V;

tic;
[ S_ML_MMSE_est,A_ML_est,lambda_ML_est ] = Compute_sources_ML_MMSE_estimate(X,C_s);
running_time = toc;
% Note that the mixing matrix A may be estimated
% up to unknown signs of its columns. This effect, while
% transparent w.r.t. *separation* of the sources, should
% be taken into account w.r.t. *estimation* of the sources
% 
%------------- END OF CODE --------------