function [ S_ML_MMSE_est,A_ML_est,lambda_ML_est ] = Compute_sources_ML_MMSE_estimate(X,C_s)
% Compute_sources_ML_MMSE_estimate - Compute the (Gaussian) sources' ML-based MMSE estimate 
%
% Syntax:  [ S_MLMMSE_est,A_ML_est,lambda_ML_est ] = Compute_sources_ML_MMSE_estimate(X,C_s)
%
% Inputs:
%    X   - The observed noisy mixtures matrix (an L x T real-valued matrix) 
%          Note I : We assume all the sources and noise (and therefore the mixtures) have zero-mean
%    C_s - The sources' temporal covariance matrices, given by their autocorrelation functions
%          (a M x T matrix, containing M autocorrelations, where C_s(m,:) is the (symmetric)
%          autocorrelation function (of length T) of the m-th source). In particular, if
%          C_s_m(:,:) is the T x T temporal covariance matrix of the m-th source, then,
%          with our notations, we have: C_s(m,:) = C_s_m(T/2+1,:),
%          where we assume T is even, for simplicity.
%          Note I  : The autocorrelations {C_s(:,m)} must be *distinct*!
%
% Outputs:
%    S_MLMMSE_est  - The ML-MMSE sources matrix' estimate (an M x T real-valued matrix)
%    A_ML_est      - The ML estimate of the mixing matrix A (an L x M real-valued matrix)
%                    Note: The ML estimate A_ML may be determined only up to (unknown)
%                    signs of each row. 
%    lambda_ML_est - The ML estimates of the noise variances (an L x 1 real-valued vector)
%                    Note: All elements of lambda_ML are non-negative.
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Based on the paper:
%			 "A Maximum Likelihood-Based Minimum Mean Square Error Separation and Estimation
%			 of Stationary Gaussian Sources from Noisy Mixtures", Amir Weiss and Arie Yeredor,
%			 submitted of IEEE Trans. on Signal Processing , August 2018.
%
% See also: readmeMLMMSE.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

% Note: This implementation follows the pseudo-code given in the paper

% Step 0: Extract parameters values
T = size(X,2);   % sample size
L = size(X,1);   % number of sensors
M = size(C_s,1); % number of sources

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 1: Compute the (row-wise) DFT of the mixtures X_tilde and the spectra
%         matrices {C_s_tilde} (e.g., via FFT)
%         Note: In practice, we do not compute the spectra matrices, but
%         rather the spectra *vectors*, representing the diagonal elements
%         of theses diagonal spectra matrices, which are denoted by
%         {P_s(m,:)}, where P_s is an M x T matrix with positive values.
%         Moreover, we compute only the first half (i.e., T/2+1 components)
%         of the (symmetric) spectra.

Xf = (1/sqrt(T))*fft(X,[],2); 
% Note I  : this is an implementation of eq. (2) from the paper
% Note II : a normalization factor is introduced in order to use a unitary DFT transformation

P_s = real(fft(ifftshift(C_s,2),[],2));
% Note I  : this is an implementation of eq. (7) from the paper, and P_s is
%           an M x T matrix, where P_s(m,:) is the spectrum of the m-th sources
% Note II : we take the real part in order to eliminate any residual of the
%           imaginary parts (which may exist due to numerical issues)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 2: Compute the MLEs A_ML_est, lambda_ML_est via the FSA eq. (27)
%         from the paper

% Set stopping criteria parameters
max_num_of_iterations = 100;
tolerance = 1e-6;

% Set initial estimates (in compliance to the ones proposed in the paper
% (see Subsection V-A, p.8-9)
A_0 = [eye(M) ; zeros(L-M,M)];
lambda_0 = min(eig(X*X'/T))*ones(1,L);

[ A_ML_est, lambda_ML_est ] =...
    Compute_MLEs_via_FSA(A_0,lambda_0,P_s,Xf,tolerance,max_num_of_iterations);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Step 3: Construct the spectral matrices C_x_tilde_est, C_sx_tilde_est
% according to eq. (40), (43), respectively, based on A_ML_est, lambda_ML_est
% Note: In fact, only the blocks of the inverse of C_x_tilde_est are required
%       for the next steps. Therefore, this following function only returns
%       Q_x_tilde_est, as defined in eq. (42) from the paper

[ Q_x_tilde_est, C_sx_tilde_est ] =...
    Compute_freq_domain_covariance_matrices_est(A_ML_est,lambda_ML_est,P_s);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Steps 4,5 & 6: Compute s_ML_MMSE_tilde_est, the DFT of the ML-based MMSE
% estimate of the sources via eq. (44), compute s_ML_MMSE_est, the
% inverse DFT of s_ML_MMSE_tilde_est, and return S_ML_MMSE_est

[ S_ML_MMSE_est ] = Compute_S_ML_MMSE_est(Q_x_tilde_est,C_sx_tilde_est,Xf);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

end
%------------- END OF CODE --------------


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------ LOCAL FUNCTIONS -----------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [ A_ML_est,lambda_ML_est ] = Compute_MLEs_via_FSA(A_0,lambda_0,P_s,Xf,tolerance,max_num_of_iterations)
% Compute_MLEs_via_FSA - Compute the ML estimates of the mixing matrix and
%                        noise variances via the Fisher Scoring Algorithm (FSA)
%
% Syntax:  [ A_ML_est,lambda_ML_est ] = Compute_MLEs_via_FSA(A_0,lambda_0,P_s,Xf,tolerance,max_num_of_iterations)
%
% Inputs:
%    A_0                   - Initial estimate of the mixing matrix A (an L x M real-value matrix)
%    lambda_0              - Initial estimate of the noise variances vector lambda (a 1 x L real-valued vector)
%    P_s                   - The sources' spectra (an M x T matrix, see desciption above)
%    Xf                    - The mixtures' (row-wise) DFT (an L x T complex-valued matrix)
%    tolerance             - a tolerance which defines the convergence. That is, we refer to the state when
%                            the cost function (norm of the step size, in this case) is smaller than tolerance
%                            as "convergence" (a scalar)
%    max_num_of_iterations - the maximum number of allowed iterations (a scalar)
%
% Outputs:
%    A_ML_est      - The MLE of the mixing matrix, A (an L x M real-value matrix)
%    lambda_ML_est - The MLE of the noise variances vector, lambda (a 1 x L real-valued vector)
%
% Other m-files required: none
% Subfunctions: Compute_FIM_noisy_Gaussian_ICA, Compute_loglikelihood_gradient
% MAT-files required: none
%
% See also: Compute_FIM_noisy_Gaussian_ICA, Compute_loglikelihood_gradient
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

L = size(Xf,1);  % number of sensors
M = size(P_s,1); % number of sources

theta = [A_0(:) ; lambda_0(:)];
% Note: this is an implementation of eq. (9) from the paper

% Initialization
lambda_ML_est = lambda_0;
A_ML_est = A_0;
cost = inf;
FSA_num_of_iterations = 0;

while cost>tolerance && FSA_num_of_iterations<max_num_of_iterations
    J = Compute_FIM_noisy_Gaussian_ICA(P_s,lambda_ML_est,A_ML_est);
    g = Compute_loglikelihood_gradient(Xf,P_s,lambda_ML_est,A_ML_est);
    step_size = J\g;
    theta = theta + step_size;
    A_ML_est = reshape(theta(1:M*L),L,M);
    lambda_ML_est = theta(M*L+1:M*L+L);
    cost = norm(step_size);
    FSA_num_of_iterations = FSA_num_of_iterations + 1;
end

end
%------------- END OF CODE --------------


function [ FIM ] = Compute_FIM_noisy_Gaussian_ICA(P_s,lambda,A)
% Compute_FIM_noisy_Gaussian_ICA - Computes the Fisher Information Matrix (FIM)
%
% Syntax:  [ FIM ] = Compute_FIM_noisy_Gaussian_ICA( P_s,sigma_v_squared_vec,A )
%
% Inputs:
%    P_s    - The sources' spectra (an M x T matrix, see desciption above)
%    lambda - The noise variances vector, lambda (a 1 x L real-valued vector)
%    A      - The mixing matrix, A (an L x M real-value matrix)
%
% Outputs:
%    FIM - The FIM (an (MxL+L) x (MxL+L) real-valued matrix)
%
% Other m-files required: none
% Subfunctions: Compute_FIM_k_th_frequency_noisy_Gaussian_ICA
% MAT-files required: none
%
% See also: Compute_FIM_k_th_frequency_noisy_Gaussian_ICA
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

L = size(A,1);   % number of sensors
M = size(A,2);   % number of sources
T = size(P_s,2); % sample size
FIM = zeros(M*L+L,M*L+L);
for k=1:(T/2+1)
    [ FIM_k ] = Compute_FIM_k_th_frequency_noisy_Gaussian_ICA(P_s(:,k),lambda,A);
    if (k==1 || k==T/2+1)
        FIM_k = 0.5*FIM_k;
    end
    FIM = FIM + FIM_k;
end

end
%------------- END OF CODE --------------


function [ FIM_k ] = Compute_FIM_k_th_frequency_noisy_Gaussian_ICA(P_sk,lambda,A)
% Compute_FIM_k_th_frequency_noisy_Gaussian_ICA - Computes the FIM of the k-th frequency component
%
% Syntax:  [ FIM_k ] = Compute_FIM_k_th_frequency_noisy_Gaussian_ICA( P_sk,lambda,A )
%
% Inputs:
%    P_sk   - The spectra' k-th frequency component of the sources (an M x 1 real-valued vector)
%    lambda - The noise variances vector, lambda (a 1 x L real-valued vector)
%    A      - The mixing matrix, A (an L x M real-value matrix)
%
% Outputs:
%    FIM_k - The FIM of the k-th frequency component (an (MxL+L) x (MxL+L) real-valued matrix)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

L = size(A,1); % number of sensors
M = size(A,2); % number of sources
FIM_k = zeros(M*L+L,M*L+L);
P_Sk = diag(P_sk);
C_k = A*P_Sk*A'+diag(lambda);
% Note: this is the (L x L) covariance matrix of the k-th frequency component mixture (vector)
C_k_inv = inv(C_k);

% FIM block of A
for j_ind=1:M
    for i_ind=1:L
        for q_ind=j_ind:M
            FIM_k( L*(j_ind-1)+i_ind, L*(q_ind-1)+1:L*(q_ind-1)+L ) = ...
                (2*P_sk(j_ind)*P_sk(q_ind)*( (C_k_inv(i_ind,:)*A(:,q_ind))*(C_k_inv*A(:,j_ind))+...
                C_k_inv(:,i_ind)*(A(:,j_ind)')*C_k_inv*A(:,q_ind)))';
            FIM_k( L*(q_ind-1)+1:L*(q_ind-1)+L, L*(j_ind-1)+i_ind ) = (FIM_k( L*(j_ind-1)+i_ind, L*(q_ind-1)+1:L*(q_ind-1)+L ))';
        end
    end
end
% Note: this is an implementation of eq. (22) from the paper

% FIM block of cross-terms (A and noise variances)
for j_ind=1:M
    for i_ind=1:L
        FIM_k( M*L+1:M*L+L, L*(j_ind-1)+i_ind ) = 2*P_sk(j_ind)*(C_k_inv(:,i_ind).*(C_k_inv*A(:,j_ind)));
        FIM_k( L*(j_ind-1)+i_ind, M*L+1:M*L+L ) = FIM_k( M*L+1:M*L+L, L*(j_ind-1)+i_ind )';
    end
end
% Note: this is an implementation of eq. (23) from the paper

% FIM block of noises' variances
FIM_k( M*L+1:M*L+L, M*L+1:M*L+L ) = C_k_inv.^2;
% Note: this is an implementation of eq. (24) from the paper

end
%------------- END OF CODE --------------


function [ Grad_Loglikelihood ] = Compute_loglikelihood_gradient(Xf,P_s,lambda,A)
% Compute_loglikelihood_gradient - Computes the gradient of the log-likelihood function
%
% Syntax:  [ Grad_Loglikelihood ] = Compute_loglikelihood_gradient(Xf,P_s,lambda,A)
%
% Inputs:
%    Xf     - The mixtures' (row-wise) DFT (an L x T complex-valued matrix)
%    P_s    - The sources' spectra (an M x T matrix, see desciption above)
%    lambda - The noise variances vector, lambda (a 1 x L real-valued vector)
%    A      - The mixing matrix, A (an L x M real-value matrix)
%
% Outputs:
%    Grad_Loglikelihood - The gradient of the log-likelihood function (a (MxL+L) x 1 real-valued vector)
%
% Other m-files required: none
% Subfunctions: Compute_loglikelihood_frequency_k_gradient
% MAT-files required: none
%
% See also: Compute_loglikelihood_frequency_k_gradient
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

L = size(A,1);  % number of sensors
M = size(A,2);  % number of sources
T = size(Xf,2); % sample size
Grad_Loglikelihood = zeros(M*L+L,1);
for k=1:(T/2+1)
    Grad_Loglikelihood_k = Compute_loglikelihood_frequency_k_gradient( Xf(:,k),P_s(:,k),A,lambda );
    if (k==1 || k==T/2+1)
        Grad_Loglikelihood_k = 0.5*Grad_Loglikelihood_k;
    end
    Grad_Loglikelihood = Grad_Loglikelihood + Grad_Loglikelihood_k;
end

end
%------------- END OF CODE --------------


function [ Grad_Loglikelihood_k ] = Compute_loglikelihood_frequency_k_gradient(x_k,P_sk,A,lambda)
% Compute_loglikelihood_frequency_k_gradient - Computes the gradient of the log-likelihood function
%                                              of the k-th frequency component
%
% Syntax:  [ Grad_Loglikelihood_k ] = compute_loglikelihood_frequency_k_gradient_B(x_k,P_sk,A,lambda)
%
% Inputs:
%    x_k    - The k-th frequency component of the mixtures (an L x 1 complex-valued vector)
%    P_sk   - The spectra' k-th frequency component of the sources (an M x 1 real-valued vector)
%    lambda - The noise variances vector, lambda (a 1 x L real-valued vector)
%    A      - The mixing matrix, A (an L x M real-value matrix)
%
% Outputs:
%    Grad_Loglikelihood_k - The gradient of the log-likelihood function of the k-th frequnecy component
%                           (a (MxL+L) x 1 real-valued vector)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

L = size(A,1); % number of sensors
M = size(A,2); % number of sources
I_L = eye(L);
P_Sk = diag(P_sk);
C_k = A*P_Sk*A'+diag(lambda);
% Note: this is the (L x L) covariance matrix of the k-th frequency component mixture (vector)
C_k_inv = inv(C_k);
R_x_k = x_k*x_k';
Grad_Loglikelihood_k = zeros(M*L+L,1);

Grad_Loglikelihood_k_matrix = 2*C_k_inv*( real(R_x_k*C_k_inv)-I_L )*A.*repmat(P_sk',L,1);
Grad_Loglikelihood_k(1:M*L) = Grad_Loglikelihood_k_matrix(:);
% Note: this is an implementation of eq. (17) from the paper

R_k = C_k_inv*R_x_k*C_k_inv;
Grad_Loglikelihood_k(M*L+1:M*L+L) = diag(R_k-C_k_inv);
% Note: this is an implementation of eq. (20) from the paper

Grad_Loglikelihood_k = real(Grad_Loglikelihood_k);
% Note II : we take the real part in order to eliminate any residual of the
%           imaginary parts (which may exist due to numerical issues)

end
%------------- END OF CODE --------------


function [ Q_x_tilde_est,C_sx_tilde_est ] =...
    Compute_freq_domain_covariance_matrices_est(A_ML_est,lambda_ML_est,P_s)
% Compute_freq_domain_covariance_matrices_est - Computes the frequency domain covariance matrix of the vectorized
%                                               version of the mixtures, C_x_tilde_est, the frequency domain
%                                               cross-covariance matrix of the vectorized version of the sources
%                                               and mixtures, C_sx_tilde_est, and the blocks according to the
%                                               block partitioning of the inverese of C_x_tilde_est, as defined
%                                               in eq. (42) from the paper.
%
% Syntax:  [ Q_x_tilde_est,C_sx_tilde_est ] =...
%               Compute_freq_domain_covariance_matrices_est(A_ML_est,lambda_ML_est,P_s)
% Inputs:
%    A_ML_est      - The MLE of the mixing matrix, A (an L x M real-value matrix)
%    lambda_ML_est - The MLE of the noise variances vector, lambda (a 1 x L real-valued vector)
%    P_s           - The sources' spectra (an M x T matrix, see desciption above)
%
% Outputs:
%    Q_x_tilde_est  - See the precise definition in eq. (42) from the paper (a T x L x L tensor)
%                     Q_x_tilde_est(:,l1,l2) - The (length T) diagonal of the (l1,l2) block
%    C_sx_tilde_est - See the precise definition in eq. (39) from the paper (a T x M x L tensor)
%                     C_sx_tilde_est(:,m,l) - The (length T) diagonal of the (m,l) block
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

L = size(A_ML_est,1); % number of sensors
M = size(A_ML_est,2); % number of sources
T = size(P_s,2);      % sample size

% Compute the block of the estimated covariance of the mixtures C_x (where x=vec(X^{T}))
C_x_tilde_est = zeros(T,L,L);
for l1=1:L
    for l2=1:L
        for m=1:M
            C_x_tilde_est(:,l1,l2) = C_x_tilde_est(:,l1,l2) + A_ML_est(l1,m)*A_ML_est(l2,m)*(P_s(m,:)');
        end
        C_x_tilde_est(:,l1,l2) = C_x_tilde_est(:,l1,l2) + (l1==l2)*lambda_ML_est(l1)*ones(T,1);
    end
end

% Compute the blocks of the inverse of the estimate of C_x
Q_x_tilde_est = zeros(T,L,L);
for t=1:T
    C_x_tilde_est_t = squeeze(C_x_tilde_est(t,:,:));
    Q_x_tilde_est(t,:,:) = inv(C_x_tilde_est_t);
end

% Compute the blocks of the estimate of the cross covariances C_sx

C_sx_tilde_est = zeros(T,M,L);
for m=1:M
    for l=1:L
        C_sx_tilde_est(:,m,l) = A_ML_est(l,m)*P_s(m,:);
    end
end

end
%------------- END OF CODE --------------


function [ S_ML_MMSE_est ] =...
    Compute_S_ML_MMSE_est(Q_x_tilde_est,C_sx_tilde_est,Xf)
% Compute_s_ML_MMSE_est - Computes the ML-based MMSE of the sources.
%
% Syntax:  [ s_ML_MMSE_est ] =...
%              Compute_S_ML_MMSE_est(C_x_tilde_est,Q_x_tilde_est,C_sx_tilde_est,Xf)
% Inputs:
%    Q_x_tilde_est  - See the precise definition in eq. (42) from the paper (a T x L x L tensor)
%                     Q_x_tilde_est(:,l1,l2) - The (length T) diagonal of the (l1,l2) block
%    C_sx_tilde_est - See the precise definition in eq. (39) from the paper (a T x M x L tensor)
%                     C_sx_tilde_est(:,m,l) - The (length T) diagonal of the (m,l) block
%    Xf             -
%
% Outputs:
%    S_ML_MMSE_est  - The ML-based MMSE estimate of the sources (an M x T real-valued matrix)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% May 2019; Last revision: 30-May-2019
%------------- BEGIN CODE --------------

L = size(C_sx_tilde_est,3); % number of sensors
M = size(C_sx_tilde_est,2); % number of sources
T = size(C_sx_tilde_est,1); % sample size

S_ML_MMSE_tilde_est = zeros(M,T);
S_ML_MMSE_est = zeros(M,T);
for m=1:M
    for l1=1:L
        for l2=1:L
            S_ML_MMSE_tilde_est(m,:) =...
                S_ML_MMSE_tilde_est(m,:) + (C_sx_tilde_est(:,m,l1)').*(Q_x_tilde_est(:,l1,l2)').*Xf(l2,:);
        end
    end
    S_ML_MMSE_est(m,:) = (sqrt(T))*ifft(S_ML_MMSE_tilde_est(m,:));
end

end
%------------- END OF CODE --------------