function [ Psi_approx_MLE_est,Phi_approx_MLE_est] =...
    Approx_ML_Estimate_calibration_errors( R_hat,psi1,phi1,phi2,T,H )
% Approx_ML_Estimate_calibration_errors - Compute the ML-OWLS estimatros of the calibration errors
%
% Inputs:
%    R_hat - The sample covariance of the observed noisy mixtures matrix of
%            the uncalibrated array
%    psi1  - Reference gain of the first sensor
%    phi1  - Reference phase of the first sensor
%    phi2  - Reference phase of the second sensor
%    T     - Number of samples based on which R_hat has been estimated
%    H     - Coefficients matrix (can be computed via the auxiliary function:
%            "generate_H_matrix_for_ML_OWLS" (see readme files for further details)
%          
%
% Outputs:
%    Psi_approx_MLE_est - The ML-OWLS estimators of the gain offset parameters
%    Phi_approx_MLE_est - The ML-OWLS estimators of the phase offset parameters
%
% Other m-files required: none
% Subfunctions: Compute_noise_covariance_matrix
%
% Based on the paper:
%			 "Asymptotically Optimal Blind Calibration of Uniform Linear
%             Sensor Arrays for Narrowband Gaussian Signals", Amir Weiss and Arie Yeredor,
%			  IEEE Trans. on Signal Processing, vol. 68, pp. 5322–5333, Aug. 2020.
%
% See also: readmeMLOWLS.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% January 2022; Last revision: 21-Jan-2022
%------------- BEGIN CODE --------------


M = size(R_hat,1);

% construct transformed "measurements" vector

mu = [];
nu = [];
for m=1:(M-1)
    mu = [mu ; real(log(R_hat(m,m:M)))'];
    nu = [nu ; imag(log(R_hat(m,m+1:M)))'];
end
mu = [mu ; real(log(R_hat(M,M)))];
y = [mu ; nu];

y = [y ; log(psi1)]; % log(psi_1) = 0 <---> psi = 1
y = [y ; phi1]; %phi_1 = 0
y = [y ; phi2]; % phi_2 = 0

% First order approximation (i.e., order of 1/T) of the noise expectation
eta_noise = zeros(length(y),1);
eta_noise(1:0.5*M*(M+1)) = -1/(2*T);

Noise_cov_matrix = Compute_noise_covariance_matrix(R_hat,T);
Lambda = zeros(M^2+3,M^2+3);
Lambda(1:M^2,1:M^2) = Noise_cov_matrix;
Lambda(M^2+1:end,M^2+1:end) = (1e-13)*eye(3);
Lambda = Lambda - eta_noise*eta_noise';
theta_approx_MLE_est = ((H'*(Lambda\H)))\((H')*(Lambda\(y-eta_noise)));
log_psi_approx_MLE_est = theta_approx_MLE_est(1:M);
Psi_approx_MLE_est = exp(log_psi_approx_MLE_est);
Phi_approx_MLE_est = theta_approx_MLE_est(M+1:2*M);

end
%------------- END OF CODE --------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------ LOCAL FUNCTIONS -----------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ Noise_cov_matrix ] = Compute_noise_covariance_matrix(R,T)
% Compute_noise_covariance_matrix - Computes the equivalent noise (approximate) covariance matrix
%
% Inputs:
%    R - Covariance matrix
%    T - Sample size          
%
% Outputs:
%    Noise_cov_matrix - The equivalent noise covarinace matrix
%
% Based on the paper:
%			 "Asymptotically Optimal Blind Calibration of Uniform Linear
%             Sensor Arrays for Narrowband Gaussian Signals", Amir Weiss and Arie Yeredor,
%			  IEEE Trans. on Signal Processing, vol. 68, pp. 5322–5333, Aug. 2020.
%
% See also: readmeMLOWLS.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% January 2022; Last revision: 21-Jan-2022
%------------- BEGIN CODE --------------
M = size(R,1);
Noise_cov_matrix = zeros(M^2,M^2);

% first block - upper left, (0.5*M*(M+1)) x (0.5*M*(M+1))
Upper_left_block = zeros(0.5*M*(M+1),0.5*M*(M+1));
row_index = 1;
for i=1:M
    for j=i:M
        column_index = 1;
        for k=1:M
            for l=k:M
                Upper_left_block(row_index,column_index) =...
                    ( R(i,k)*conj(R(j,l)) )/( R(i,j)*conj(R(k,l)) ) +...
                    ( R(i,l)*conj(R(j,k)) )/( R(i,j)*R(k,l) );
                column_index = column_index + 1;
            end
        end
        row_index = row_index + 1;
    end
end
Upper_left_block = 0.5*real(Upper_left_block)/T;
Noise_cov_matrix(1:0.5*M*(M+1),1:0.5*M*(M+1)) = Upper_left_block;

% second block - lower right, (0.5*M*(M-1)) x (0.5*M*(M-1))
Lower_right_block = zeros(0.5*M*(M-1),0.5*M*(M-1));
row_index = 1;
for i=1:M
    for j=(i+1):M
        column_index = 1;
        for k=1:M
            for l=(k+1):M
                Lower_right_block(row_index,column_index) =...
                    ( R(i,k)*conj(R(j,l)) )/( R(i,j)*conj(R(k,l)) ) -...
                    ( R(i,l)*conj(R(j,k)) )/( R(i,j)*R(k,l) );
                column_index = column_index + 1;
            end
        end
        row_index = row_index + 1;
    end
end
Lower_right_block = 0.5*real(Lower_right_block)/T;
Noise_cov_matrix(0.5*M*(M+1)+1:end,0.5*M*(M+1)+1:end) = Lower_right_block;

% third (=fourth) block - upper right, (0.5*M*(M+1)) x (0.5*M*(M-1))
Upper_right_block = zeros(0.5*M*(M+1),0.5*M*(M-1));
row_index = 1;
for i=1:M
    for j=i:M
        column_index = 1;
        for k=1:M
            for l=(k+1):M
                Upper_right_block(row_index,column_index) =...
                    ( R(i,l)*conj(R(j,k)) )/( R(i,j)*R(k,l) ) -...
                    ( R(i,k)*conj(R(j,l)) )/( R(i,j)*conj(R(k,l)) );
                column_index = column_index + 1;
            end
        end
        row_index = row_index + 1;
    end
end
Upper_right_block = 0.5*imag(Upper_right_block)/T;
Noise_cov_matrix(1:0.5*M*(M+1),0.5*M*(M+1)+1:end) = Upper_right_block;
Noise_cov_matrix(0.5*M*(M+1)+1:end,1:0.5*M*(M+1)) = Upper_right_block';

end
%------------- END OF CODE --------------