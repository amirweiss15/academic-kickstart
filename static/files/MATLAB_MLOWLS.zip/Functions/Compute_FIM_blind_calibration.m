function [ FIM ] =...
    Compute_FIM_blind_calibration( Psi,Phi,theta,sigma_s_squared,sigma_n_squared,T )
% Approx_ML_Estimate_calibration_errors - Computes respective Fisher Information Matrix
%
% We assume only Phi(3),...,Phi(M) are unknown, while Phi(1) and Phi(2) are assumed
% to be known. Further, we assume Psi(1)=1 is known and Psi(2),...,Psi(M) are unknowns.
%
% Inputs:
%    Psi             - The gain offset parameters
%    Psi             - The phase offset parameters
%    sigma_s_squared - The sources' power
%    sigma_n_squared - The noise power
%    T               - Number of samples based on which R_hat has been estimated
%          
%
% Outputs:
%    FIM - The Fisher Information Matrix
%
% Other m-files required: none
% Subfunctions: none
%
% Based on the paper:
%			 "Asymptotically Optimal Blind Calibration of Uniform Linear
%             Sensor Arrays for Narrowband Gaussian Signals", Amir Weiss and Arie Yeredor,
%			  IEEE Trans. on Signal Processing, vol. 68, pp. 5322–5333, Aug. 2020.
%
% See also: readmeMLOWLS.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% January 2022; Last revision: 21-Jan-2022
%------------- BEGIN CODE --------------

M = length(Psi);
D = length(theta);
FIM = zeros(2*(M+D)-2,2*(M+D)-2);
I_M = eye(M);

% Compute covariance matrix C
kl = pi;
A_theta = exp(1i*kl*((0:M-1)')*cos(theta));
xi = A_theta*diag(sigma_s_squared)*A_theta';
R = diag(Psi)*diag(exp(1i*Phi))*xi*diag(exp(-1i*Phi))*diag(Psi)+...
    diag(Psi.^2)*sigma_n_squared;
inv_R = inv(R);
C_phi_theta = diag(exp(1i*Phi))*xi*diag(exp(-1i*Phi));
G_psi_theta = diag(Psi)*xi*diag(Psi);
l_column = repmat((1:M),M,1);
l_row = l_column';
dRdsigma_n_squared = diag(Psi.*Psi);

% Block (Psi,Psi) ---> (1:M-1,1:M-1)
for m1_ind=1:(M-1)
    m1 = m1_ind + 1;
    E_m1m1 = I_M(:,m1)*I_M(m1,:);
    dRdPsi_m1 = diag(Psi)*C_phi_theta*E_m1m1 + (diag(Psi)*C_phi_theta*E_m1m1)' +...
        2*Psi(m1)*sigma_n_squared*E_m1m1;
    for m2_ind=1:m1_ind
        m2 = m2_ind + 1;
        E_m2m2 = I_M(:,m2)*I_M(m2,:);
        dRdPsi_m2 = diag(Psi)*C_phi_theta*E_m2m2 + (diag(Psi)*C_phi_theta*E_m2m2)' +...
            2*Psi(m2)*sigma_n_squared*E_m2m2;
        FIM(m1_ind,m2_ind) = trace(inv_R*dRdPsi_m1*inv_R*dRdPsi_m2);
        if m1_ind~=m2_ind
            FIM(m2_ind,m1_ind) = FIM(m1_ind,m2_ind);
        end
    end
end

% Block (Psi,Phi) and (Phi,Psi)
FIM_Psi_Phi = zeros(M-1,M-2);
for m1_ind=1:(M-1)
    m1 = m1_ind + 1;
    E_m1m1 = I_M(:,m1)*I_M(m1,:);
    dRdPsi_m1 = diag(Psi)*C_phi_theta*E_m1m1 + (diag(Psi)*C_phi_theta*E_m1m1)' +...
        2*Psi(m1)*sigma_n_squared*E_m1m1;
    for m2_ind=1:(M-2)
        m2 = m2_ind + 2;
        E_m2m2 = I_M(:,m2)*I_M(m2,:);
        dRdPhi_m2 = 1i*(exp(1i*Phi(m2))*E_m2m2*G_psi_theta*diag(exp(-1i*Phi))-...
            diag(exp(1i*Phi))*G_psi_theta*E_m2m2*(exp(-1i*Phi(m2))));
        FIM_Psi_Phi(m1_ind,m2_ind) = trace(inv_R*dRdPsi_m1*inv_R*dRdPhi_m2);
    end
end
% Block (Psi,Phi) ---> (1:M-1,M:2*M-3)
FIM(1:M-1,M:2*M-3) = FIM_Psi_Phi;
% Block (Phi,Psi) ---> (M:2*M-3,1:M-1)
FIM(M:2*M-3,1:M-1) = FIM_Psi_Phi';

% Block (Psi,theta) and (theta,Psi)
FIM_Psi_theta = zeros(M-1,D);
% Block (Psi,sigma_s_squared) and (sigma_s_squared,Psi)
FIM_Psi_sigma_s_squared = zeros(M-1,D);

for m_ind=1:(M-1)
    m = m_ind + 1;
    E_mm = I_M(:,m)*I_M(m,:);
    dRdPsi_m = diag(Psi)*C_phi_theta*E_mm + (diag(Psi)*C_phi_theta*E_mm)' +...
        2*Psi(m)*sigma_n_squared*E_mm;
    for d=1:D
        Q_d = -1i*sigma_s_squared(d)*kl*sin(theta(d))*...
            (l_row-l_column).*exp(1i*(l_row-l_column)*kl*cos(theta(d)));
        dRdtheta_d = diag(Psi)*diag(exp(1i*Phi))*Q_d*diag(Psi)*diag(exp(-1i*Phi));
        FIM_Psi_theta(m_ind,d) = trace(inv_R*dRdPsi_m*inv_R*dRdtheta_d);
        dRdsigma_s_squared =...
            diag(Psi)*diag(exp(1i*Phi))*A_theta(:,d)*(A_theta(:,d)')*diag(Psi)*diag(exp(-1i*Phi));
        FIM_Psi_sigma_s_squared(m_ind,d) = trace(inv_R*dRdPsi_m*inv_R*dRdsigma_s_squared);
    end
end
% Block (Psi,theta) ---> (1:M-1,2*M-2:2*M+D-3)
FIM(1:M-1,2*M-2:2*M+D-3) = FIM_Psi_theta;
% Block (theta,Psi) ---> (2*M-2:2*M+D-3,1:M-1)
FIM(2*M-2:2*M+D-3,1:M-1) = FIM_Psi_theta';
% Block (Psi,sigma_s_squared) ---> (1:M-1,2*M+D-2:2*M+2*D-3)
FIM(1:M-1,2*M+D-2:2*M+2*D-3) = FIM_Psi_sigma_s_squared;
% Block (sigma_s_squared,Psi) ---> (2*M+D-2:2*M+2*D-3,1:M-1)
FIM(2*M+D-2:2*M+2*D-3,1:M-1) = FIM_Psi_sigma_s_squared';

% Block (Psi,sigma_n_squared) ---> (1:M-1,2*M+2*D-2)
for m_ind=1:(M-1)
    m = m_ind + 1;
    E_mm = I_M(:,m)*I_M(m,:);
    dRdPsi_m = diag(Psi)*C_phi_theta*E_mm + (diag(Psi)*C_phi_theta*E_mm)' +...
        2*Psi(m)*sigma_n_squared*E_mm;
    FIM(m_ind,2*M+2*D-2) = trace(inv_R*dRdPsi_m*inv_R*dRdsigma_n_squared);
end
% Block (sigma_n_squared,Psi) ---> (2*M+2*D-2,1:M-1)
FIM(2*M+2*D-2,1:M-1) = FIM(1:M-1,2*M+2*D-2)';

% Block (Phi,Phi) ---> (M:2*M-3,M:2*M-3)
FIM_Phi_Phi = zeros(M-2,M-2);
for m1_ind=1:(M-2)
    m1 = m1_ind + 2;
    E_m1m1 = I_M(:,m1)*I_M(m1,:);
    dRdPhi_m1 = 1i*(exp(1i*Phi(m1))*E_m1m1*G_psi_theta*diag(exp(-1i*Phi))-...
        diag(exp(1i*Phi))*G_psi_theta*E_m1m1*(exp(-1i*Phi(m1))));
    for m2_ind=1:m1_ind
        m2 = m2_ind + 2;
        E_m2m2 = I_M(:,m2)*I_M(m2,:);
        dRdPhi_m2 = 1i*(exp(1i*Phi(m2))*E_m2m2*G_psi_theta*diag(exp(-1i*Phi))-...
            diag(exp(1i*Phi))*G_psi_theta*E_m2m2*(exp(-1i*Phi(m2))));
        FIM_Phi_Phi(m1_ind,m2_ind) = trace(inv_R*dRdPhi_m1*inv_R*dRdPhi_m2);
        if m1_ind~=m2_ind
            FIM_Phi_Phi(m2_ind,m1_ind) = FIM_Phi_Phi(m1_ind,m2_ind);
        end
    end
end
FIM(M:2*M-3,M:2*M-3) = FIM_Phi_Phi;

% Block (Phi,theta) and (theta,Phi)
FIM_Phi_theta = zeros(M-2,D);
% Block (Phi,sigma_s_squared) and (sigma_s_squared,Phi)
FIM_Phi_sigma_s_squared = zeros(M-2,D);
for m_ind=1:(M-2)
    m = m_ind + 2;
    E_mm = I_M(:,m)*I_M(m,:);
    dRdPhi_m = 1i*(exp(1i*Phi(m))*E_mm*G_psi_theta*diag(exp(-1i*Phi))-...
        diag(exp(1i*Phi))*G_psi_theta*E_mm*(exp(-1i*Phi(m))));
    for d=1:D
        Q_d = -1i*sigma_s_squared(d)*kl*sin(theta(d))*...
            (l_row-l_column).*exp(1i*(l_row-l_column)*kl*cos(theta(d)));
        dRdtheta_d = diag(Psi)*diag(exp(1i*Phi))*Q_d*diag(Psi)*diag(exp(-1i*Phi));
        FIM_Phi_theta(m_ind,d) = trace(inv_R*dRdPhi_m*inv_R*dRdtheta_d);
        dRdsigma_s_squared =...
            diag(Psi)*diag(exp(1i*Phi))*A_theta(:,d)*(A_theta(:,d)')*diag(Psi)*diag(exp(-1i*Phi));
        FIM_Phi_sigma_s_squared(m_ind,d) = trace(inv_R*dRdPhi_m*inv_R*dRdsigma_s_squared);
    end
end
% Block (Phi,theta) ---> (M:2*M-3,2*M-2:2*M+D-3)
FIM(M:2*M-3,2*M-2:2*M+D-3) = FIM_Phi_theta;
% Block (theta,Phi) ---> (2*M-2:2*M+D-3,M:2*M-3)
FIM(2*M-2:2*M+D-3,M:2*M-3) = FIM_Phi_theta';
% Block (Phi,sigma_s_squared) ---> (M:2*M-3,2*M+D-2:2*M+2*D-3)
FIM(M:2*M-3,2*M+D-2:2*M+2*D-3) = FIM_Phi_sigma_s_squared;
% Block (sigma_s_squared,Phi) ---> (2*M+D-2:2*M+2*D-3,M:2*M-3)
FIM(2*M+D-2:2*M+2*D-3,M:2*M-3) = FIM_Phi_sigma_s_squared';

% Block (Phi,sigma_n_squared) ---> (M:2*M-3,2*M+2*D-2)
for m_ind=1:(M-2)
    m = m_ind + 2;
    E_mm = I_M(:,m)*I_M(m,:);
    dRdPhi_m = 1i*(exp(1i*Phi(m))*E_mm*G_psi_theta*diag(exp(-1i*Phi))-...
        diag(exp(1i*Phi))*G_psi_theta*E_mm*(exp(-1i*Phi(m))));
    FIM(M+m_ind-1,2*M+2*D-2) = trace(inv_R*dRdPhi_m*inv_R*dRdsigma_n_squared);
end
% Block (sigma_n_squared,Phi) ---> (2*M+2*D-2,M:2*M-3)
FIM(2*M+2*D-2,M:2*M-3) = FIM(M:2*M-3,2*M+2*D-2)';

% Block (theta,theta) ---> (2*M-2:2*M+D-3,2*M-2:2*M+D-3)
FIM_theta_theta = zeros(D,D);
for d1=1:D
    Q_d1 = -1i*sigma_s_squared(d1)*kl*sin(theta(d1))*...
        (l_row-l_column).*exp(1i*(l_row-l_column)*kl*cos(theta(d1)));
    dRdtheta_d1 = diag(Psi)*diag(exp(1i*Phi))*Q_d1*diag(Psi)*diag(exp(-1i*Phi));
    for d2=1:d1
        Q_d2 = -1i*sigma_s_squared(d2)*kl*sin(theta(d2))*...
            (l_row-l_column).*exp(1i*(l_row-l_column)*kl*cos(theta(d2)));
        dRdtheta_d2 = diag(Psi)*diag(exp(1i*Phi))*Q_d2*diag(Psi)*diag(exp(-1i*Phi));
        FIM_theta_theta(d1,d2) = trace(inv_R*dRdtheta_d1*inv_R*dRdtheta_d2);
        if d1~=d2
            FIM_theta_theta(d2,d1) = FIM_theta_theta(d1,d2);
        end
    end
end
FIM(2*M-2:2*M+D-3,2*M-2:2*M+D-3) = FIM_theta_theta;

% Block (theta,sigma_s_squared) and (sigma_s_squared,theta)
FIM_theta_sigma_s_squared = zeros(D,D);
for d1=1:D
    Q_d1 = -1i*sigma_s_squared(d1)*kl*sin(theta(d1))*...
        (l_row-l_column).*exp(1i*(l_row-l_column)*kl*cos(theta(d1)));
    dRdtheta_d1 = diag(Psi)*diag(exp(1i*Phi))*Q_d1*diag(Psi)*diag(exp(-1i*Phi));
    for d2=1:D
        dRdsigma_s_squared =...
            diag(Psi)*diag(exp(1i*Phi))*A_theta(:,d2)*(A_theta(:,d2)')*diag(Psi)*diag(exp(-1i*Phi));
        FIM_theta_sigma_s_squared(d1,d2) = trace(inv_R*dRdtheta_d1*inv_R*dRdsigma_s_squared);
    end
end
% Block (theta,sigma_s_squared) ---> (2*M-2:2*M+D-3,2*M+D-2:2*M+2*D-3)
FIM(2*M-2:2*M+D-3,2*M+D-2:2*M+2*D-3) = FIM_theta_sigma_s_squared;
% Block (sigma_s_squared,theta) ---> (2*M+D-2:2*M+2*D-3,2*M-2:2*M+D-3)
FIM(2*M+D-2:2*M+2*D-3,2*M-2:2*M+D-3) = FIM_theta_sigma_s_squared';

% Block (theta,sigma_n_squared) ---> (2*M-2:2*M+D-3,2*M+2*D-2)
for d=1:D
    Q_d = -1i*sigma_s_squared(d)*kl*sin(theta(d))*...
        (l_row-l_column).*exp(1i*(l_row-l_column)*kl*cos(theta(d)));
    dRdtheta_d = diag(Psi)*diag(exp(1i*Phi))*Q_d*diag(Psi)*diag(exp(-1i*Phi));
    FIM(2*M+d-3,2*M+2*D-2) = trace(inv_R*dRdtheta_d*inv_R*dRdsigma_n_squared);
end
% Block (sigma_n_squared,theta) ---> (2*M+2*D-2,2*M-2:2*M+D-3)
FIM(2*M+2*D-2,2*M-2:2*M+D-3) = FIM(2*M-2:2*M+D-3,2*M+2*D-2)';

% Block (sigma_s_squared,sigma_s_squared) ---> (2*M+D-2:2*M+2*D-3,2*M+D-2:2*M+2*D-3)
FIM_sigma_s_squared_sigma_s_squared = zeros(D,D);
for d1=1:D
    dRdsigma_s_squared_d1 =...
        diag(Psi)*diag(exp(1i*Phi))*A_theta(:,d1)*(A_theta(:,d1)')*diag(Psi)*diag(exp(-1i*Phi));
    for d2=1:d1
        dRdsigma_s_squared_d2 =...
            diag(Psi)*diag(exp(1i*Phi))*A_theta(:,d2)*(A_theta(:,d2)')*diag(Psi)*diag(exp(-1i*Phi));
        FIM_sigma_s_squared_sigma_s_squared(d1,d2) =...
            trace(inv_R*dRdsigma_s_squared_d1*inv_R*dRdsigma_s_squared_d2);
        if d1~=d2
            FIM_sigma_s_squared_sigma_s_squared(d2,d1) = FIM_sigma_s_squared_sigma_s_squared(d1,d2);
        end
    end
end
FIM(2*M+D-2:2*M+2*D-3,2*M+D-2:2*M+2*D-3) = FIM_sigma_s_squared_sigma_s_squared;

% Block (sigma_s_squared,sigma_n_squared) ---> (2*M+D-2:2*M+2*D-3,2*M+2*D-2)
for d=1:D
    dRdsigma_s_squared =...
        diag(Psi)*diag(exp(1i*Phi))*A_theta(:,d)*(A_theta(:,d)')*diag(Psi)*diag(exp(-1i*Phi));
    FIM(2*M+D+d-3,2*M+2*D-2) = trace(inv_R*dRdsigma_s_squared*inv_R*dRdsigma_n_squared);
end
% Block (sigma_n_squared,sigma_s_squared) ---> (2*M+2*D-2,2*M+D-2:2*M+2*D-3)
FIM(2*M+2*D-2,2*M+D-2:2*M+2*D-3) = FIM(2*M+D-2:2*M+2*D-3,2*M+2*D-2)';

% Block (sigma_n_squared,sigma_n_squared) ---> (2*M+2*D-2,2*M+2*D-2)
FIM(2*M+2*D-2,2*M+2*D-2) = trace(inv_R*dRdsigma_n_squared*inv_R*dRdsigma_n_squared);

FIM = T*real(FIM);
%------------- END OF CODE --------------