function [ Psi_est,Phi_est] =...
    Estimate_calibration_errors_Kailath_indices( R_hat,Psi1,Phi1,Phi2 )
% Estimate_calibration_errors_Kailath_indices - Computes Paulraj and Kailath’s LS estimatros
%
% Inputs:
%    R_hat - The sample covariance of the observed noisy mixtures matrix of
%            the uncalibrated array
%    Psi1  - Reference gain of the first sensor
%    Phi1  - Reference phase of the first sensor
%    Phi2  - Reference phase of the second sensor
%          
%
% Outputs:
%    Psi_est - The LS estimators of the gain offset parameters
%    Phi_est - The LS estimators of the phase offset parameters
%
% Other m-files required: none
% Subfunctions: none
%
% Based on the paper:
%			 "Asymptotically Optimal Blind Calibration of Uniform Linear
%             Sensor Arrays for Narrowband Gaussian Signals", Amir Weiss and Arie Yeredor,
%			  IEEE Trans. on Signal Processing, vol. 68, pp. 5322–5333, Aug. 2020.
%
% See also: readmeMLOWLS.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% January 2022; Last revision: 21-Jan-2022
%------------- BEGIN CODE --------------
M = size(R_hat,1);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimation of the sensor gain
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

k_psi = 0;
for i=2:M
    k_psi = k_psi + i*(i-1);
end
k_psi = k_psi*0.5;

mu_vec = zeros(k_psi,1);
H1 = zeros(k_psi,M);
vector_of_indices_for_noise_psi = zeros(k_psi,4);

row_index = 1;
for diag_ind=0:M-2
    current_diag = diag(R_hat,diag_ind);
    if diag_ind==0 %main diagonal ---> i=j and k=l
        for i=1:(M-1)
            for k=i+1:M
                row_vec_of_H1 = zeros(1,M);
                row_vec_of_H1(i) = 2;
                row_vec_of_H1(k) = -2;
                H1(row_index,:) = row_vec_of_H1;
                vector_of_indices_for_noise_psi(row_index,:) = [i i k k];
                mu_vec(row_index) = log(abs(current_diag(i)/current_diag(k)));
                row_index = row_index + 1;
            end
        end
    else % super diagonals i~=j and k~=l
        if diag_ind==1 % first super diagonal
            for i=1:(M-2)
                j = i+1;
                k = j;
                l = k+1;
                row_vec_of_H1 = zeros(1,M);
                row_vec_of_H1(i) = 1;
                row_vec_of_H1(l) = -1;
                H1(row_index,:) = row_vec_of_H1;
                vector_of_indices_for_noise_psi(row_index,:) = [i j k l];
                mu_vec(row_index) = log(abs(current_diag(i)/current_diag(i+1)));
                row_index = row_index + 1;
                j = i + diag_ind;
                for k=(j+1):(M-diag_ind)  
                    l = k + diag_ind;
                    row_vec_of_H1 = zeros(1,M);
                    row_vec_of_H1(i) = 1;
                    row_vec_of_H1(j) = 1;
                    row_vec_of_H1(k) = -1;
                    row_vec_of_H1(l) = -1;
                    H1(row_index,:) = row_vec_of_H1;
                    vector_of_indices_for_noise_psi(row_index,:) = [i j k l];
                    mu_vec(row_index) = log(abs(current_diag(i)/current_diag(k)));
                    row_index = row_index + 1;
                end
            end
        else % super diagonal but not the first
            for i=1:(M-diag_ind-1)
                j = i + diag_ind;
                for k=(i+1):(M-diag_ind)
                    l = k + diag_ind;
                    row_vec_of_H1 = zeros(1,M);
                    if j==k
                        row_vec_of_H1(i) = 1;
                        row_vec_of_H1(l) = -1;
                    else
                        row_vec_of_H1(i) = 1;
                        row_vec_of_H1(j) = 1;
                        row_vec_of_H1(k) = -1;
                        row_vec_of_H1(l) = -1;
                    end
                    H1(row_index,:) = row_vec_of_H1;
                    vector_of_indices_for_noise_psi(row_index,:) = [i j k l];
                    mu_vec(row_index) = log(abs(current_diag(i)/current_diag(k)));
                    row_index = row_index + 1;
                end
            end
        end
    end
end

mu_vec = [mu_vec ; log(Psi1)];
H1 = [H1 ; 1 zeros(1,M-1)];
% LS estimate
log_psi_est = H1\mu_vec;
Psi_est = exp(log_psi_est);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Estimation of the sensor phase
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

k_phi = 0;
for i=2:(M-1)
    k_phi = k_phi + i*(i-1);
end
k_phi = k_phi*0.5;

nu_vec = zeros(k_phi,1);
vector_of_indices_for_noise_phi = zeros(k_phi,4);
H2 = zeros(k_phi,M);

row_index = 1;
for diag_ind=1:M-2
    current_diag = diag(R_hat,diag_ind);
    if diag_ind==1 % first super diagonal
        for i=1:(M-diag_ind-1)
            j = i + diag_ind;
            k = j;
            l = k + diag_ind;
            row_vec_of_H2 = zeros(1,M);
            row_vec_of_H2(i) = 1;
            row_vec_of_H2(k) = -2;
            row_vec_of_H2(l) = 1;
            H2(row_index,:) = row_vec_of_H2;
            vector_of_indices_for_noise_phi(row_index,:) = [i j k l];
            nu_vec(row_index) = angle(current_diag(i)) - angle(current_diag(k));
            row_index = row_index + 1;
            for k=(i+2):(M-diag_ind)
                l = k + diag_ind;
                row_vec_of_H2 = zeros(1,M);
                row_vec_of_H2(i) = 1;
                row_vec_of_H2(j) = -1;
                row_vec_of_H2(k) = -1;
                row_vec_of_H2(l) = 1;
                H2(row_index,:) = row_vec_of_H2;
                vector_of_indices_for_noise_phi(row_index,:) = [i j k l];
                nu_vec(row_index) = angle(current_diag(i)) - angle(current_diag(k));
                row_index = row_index + 1;
            end
        end
    else % super diagonal but not the first
        for i=1:(M-diag_ind-1)
            j = i + diag_ind;
            for k=(i+1):(M-diag_ind)
                l = k + diag_ind;
                row_vec_of_H2 = zeros(1,M);
                if j==k
                    row_vec_of_H2(i) = 1;
                    row_vec_of_H2(j) = -2;
                    row_vec_of_H2(l) = 1;
                else
                    row_vec_of_H2(i) = 1;
                    row_vec_of_H2(j) = -1;
                    row_vec_of_H2(k) = -1;
                    row_vec_of_H2(l) = 1;
                end
                H2(row_index,:) = row_vec_of_H2;
                vector_of_indices_for_noise_phi(row_index,:) = [i j k l];
                nu_vec(row_index) = angle(current_diag(i)) - angle(current_diag(k));
                row_index = row_index + 1;
            end
        end
    end
end

nu_vec = [nu_vec ; Phi1 ; Phi2];
H2 = [H2 ; [1 zeros(1,M-1)] ; [0 1 zeros(1,M-2)]];
Phi_est = H2\nu_vec;

end
%------------- END OF CODE --------------
