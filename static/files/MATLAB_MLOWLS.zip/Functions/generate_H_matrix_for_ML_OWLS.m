function [ H ] = generate_H_matrix_for_ML_OWLS( M )
% Approx_ML_Estimate_calibration_errors - Generate the matrix of
% coefficients required for the computation of the ML-OWLS estimator
%
% Inputs:
%    M - Number of sensros in the uniform linear array          
%
% Outputs:
%    H - the matrix of coefficients (see Appendix A of the paper below for
%    details)
%
% Other m-files required: none
% Subfunctions: none
%
% Based on the paper:
%			 "Asymptotically Optimal Blind Calibration of Uniform Linear
%             Sensor Arrays for Narrowband Gaussian Signals", Amir Weiss and Arie Yeredor,
%			  IEEE Trans. on Signal Processing, vol. 68, pp. 5322–5333, Aug. 2020.
%
% See also: readmeMLOWLS.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% January 2022; Last revision: 21-Jan-2022
%------------- BEGIN CODE --------------

H = zeros(M^2,4*M-1);

% upper part of H - related to mu

H_row_index = 1;
for i=1:M
    for j=i:M
        if i==j
            H(H_row_index,i) = 2;
        else
            H(H_row_index,i) = 1;
            H(H_row_index,j) = 1;
        end
        H(H_row_index,2*M+1+(j-i)) = 1;
        H_row_index = H_row_index + 1;
    end
end

% lower part of H - related to nu

for i=1:M % should be until M-1, but it doesn't matter in this implementation
    for j=(i+1):M
        H(H_row_index,M+i) = 1;
        H(H_row_index,M+j) = -1;
        H(H_row_index,3*M+(j-i)) = 1;
        H_row_index = H_row_index + 1;
    end
end

H(H_row_index,1) = 1; % log(psi_1) = 0 <---> psi = 1
H(H_row_index+1,M+1) = 1; %phi_1 = 0
H(H_row_index+2,M+2) = 1; % phi_2 = 0

end
%------------- END OF CODE --------------