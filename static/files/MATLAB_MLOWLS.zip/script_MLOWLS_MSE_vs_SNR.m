% Script - Demonstration of the ML-OWLS blind calibration algorithm
% In this example, we consider an array with 5 sensors and the presence of
% 3 narrowband sources. The output is the performance in terms of the MSE
% versus the SNR, for a fixed sample size.
%
% Other m-files required: Compute_FIM_blind_calibration.m
%                         Approx_ML_Estimate_calibration_errors.m
%                         Estimate_calibration_errors_Kailath_indices.m
%
% Based on the paper:
%			 "Asymptotically Optimal Blind Calibration of Uniform Linear
%             Sensor Arrays for Narrowband Gaussian Signals", Amir Weiss and Arie Yeredor,
%			  IEEE Trans. on Signal Processing, vol. 68, pp. 5322–5333, Aug. 2020.
%
% See also: readmeMLOWLS.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% January 2022; Last revision: 21-Jan-2022
%------------- BEGIN CODE --------------

clear;
close all;
clc;

addpath('Functions');

M = 5; % number of sensors
D = 3; % number of sources
T = 500; % samples size
% Unknown parameters
% for M=5 and D=3
Psi = [1 1.3 1.1 0.7 2.2]; % gain of sensors
Phi = (pi/180)*[0 0 5 11 -8]; % phase of sensors
theta_deg = [-35 -73 -28]; % DOA of the sources [deg]
theta = (pi/180)*theta_deg; % DOA of the sources [rad]
sigma_s_squared = [1 1 1]; % power of the sources
SNR_dB_vec = linspace(0,15,10);
% SNR_dB_vec = linspace(0,15,5);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% we assume k=2*pi/lambda and l=lambda/2, where k is the wavenumber
% and l is the inter-element spacing. Thus, k*l=pi.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
kl = pi;

% generate the array manifold matrix
A_theta = exp(1i*kl*((0:M-1)')*cos(theta));

num_of_trials = 1e4;
Psi_MSE_LS = zeros(length(Psi),num_of_trials,length(SNR_dB_vec));
Psi_MSE_approx_MLE = zeros(length(Psi),num_of_trials,length(SNR_dB_vec));
Phi_MSE_LS = zeros(length(Phi),num_of_trials,length(SNR_dB_vec));
Phi_MSE_approx_MLE = zeros(length(Phi),num_of_trials,length(SNR_dB_vec));
DOA_RMSE_LS = zeros(D,num_of_trials,length(SNR_dB_vec));
DOA_RMSE_WLS = zeros(D,num_of_trials,length(SNR_dB_vec));
DOA_RMSE_WLS_approx = zeros(D,num_of_trials,length(SNR_dB_vec));
CRLB_Psi = zeros(length(Psi),length(SNR_dB_vec));
CRLB_Phi = zeros(length(Phi),length(SNR_dB_vec));

H = generate_H_matrix_for_ML_OWLS( M );

h_bar2 = waitbar(0,'SNR');
for SNR_ind=1:length(SNR_dB_vec)
    SNR_lin = 10^(SNR_dB_vec(SNR_ind)/10);
    sigma_n_squared = 1/SNR_lin; % power of additive noise
    FIM = Compute_FIM_blind_calibration(Psi,Phi,theta,sigma_s_squared,sigma_n_squared,T);
    CRLB = inv(FIM);
    diag_CRLB = diag(CRLB);
    CRLB_Psi(2:end,SNR_ind) = diag_CRLB(1:M-1);
    CRLB_Phi(3:end,SNR_ind) = diag_CRLB((M-1)+1:(M-1)+1+(M-2)-1);
    R =...
        diag(Psi)*diag(exp(1i*Phi))*...
        (A_theta*diag(sigma_s_squared)*A_theta'+sigma_n_squared*eye(M))*...
        diag(exp(-1i*Phi))*diag(Psi);
    h_bar1 = waitbar(0,'Monte Carlo');
    for trial_ind=1:num_of_trials
        % Generate the sources (circular complex normal)
        S = diag(sqrt(sigma_s_squared))*(1/sqrt(2))*(randn(D,T)+1i*randn(D,T));
        % Generate the noise (circular complex normal)
        N = sqrt(sigma_n_squared)*(1/sqrt(2))*(randn(M,T)+1i*randn(M,T));
        % Generate the noisy mixtures
        X = diag(Psi)*diag(exp(1i*Phi))*(A_theta*S+N);
        % Estimate the sufficient statistic - the (zero-lag) empirical correlation matrix
        R_hat = (X*X')/T;
        % Estimate the gains and phases
        [ Psi_approx_MLE_est,Phi_approx_MLE_est] =...
            Approx_ML_Estimate_calibration_errors( R_hat,Psi(1),Phi(1),Phi(2),T,H );
        [ Psi_est_LS,Phi_est_LS ] =...
            Estimate_calibration_errors_Kailath_indices( R_hat,Psi(1),Phi(1),Phi(2) );
        %Compute empirical MSEs
        Psi_MSE_LS(:,trial_ind,SNR_ind) = (Psi_est_LS-Psi').^2;
        Psi_MSE_approx_MLE(:,trial_ind,SNR_ind) = (Psi_approx_MLE_est-Psi').^2;
        Phi_MSE_LS(:,trial_ind,SNR_ind) = (Phi_est_LS-Phi').^2;
        Phi_MSE_approx_MLE(:,trial_ind,SNR_ind) = (Phi_approx_MLE_est-Phi').^2;        
        waitbar(trial_ind/num_of_trials,h_bar1);
    end
    close(h_bar1);
    waitbar(SNR_ind/length(SNR_dB_vec),h_bar2);
end
close(h_bar2);

Psi_Average_MSE_LS = mean(Psi_MSE_LS,2);
Psi_Average_MSE_approx_MLE = mean(Psi_MSE_approx_MLE,2);

Phi_Average_MSE_LS = mean(Phi_MSE_LS,2);
Phi_Average_MSE_approx_MLE = mean(Phi_MSE_approx_MLE,2);

% plot results


figure('units','normalized','outerposition',[0 0 1 1]);
for m=2:M
    subplot(1,(M-1)+(M-2),m-1);
    plot(SNR_dB_vec,10*log10(Psi_Average_MSE_LS(m,:)),'ok','linewidth',2,'MarkerSize',7);
    hold;
    plot(SNR_dB_vec,10*log10(Psi_Average_MSE_approx_MLE(m,:)),'xr','linewidth',2,'MarkerSize',9);
    plot(SNR_dB_vec,10*log10(CRLB_Psi(m,:)),'b','linewidth',2);
    xlabel('SNR [dB]'); ylabel('MSE [dB]'); title(['\boldmath$\widehat{\Psi}_',num2str(m),'$'],'Interpreter','latex');
    grid;
    set(gca,'linewidth',2);
    set(gca,'FontName','CMU Serif');
    set(gca,'FontSize',15);
end
for m=3:M
    subplot(1,(M-1)+(M-2),M-1+m-2);
    plot(SNR_dB_vec,10*log10(Phi_Average_MSE_LS(m,:)),'ok','linewidth',2,'MarkerSize',7);
    hold;
    plot(SNR_dB_vec,10*log10(Phi_Average_MSE_approx_MLE(m,:)),'xr','linewidth',2,'MarkerSize',9);
    plot(SNR_dB_vec,10*log10(CRLB_Phi(m,:)),'b','linewidth',2);
    xlabel('SNR [dB]'); ylabel('MSE [dB]'); title(['\boldmath$\widehat{\phi}_',num2str(m),'$'],'Interpreter','latex');
    grid;
    set(gca,'linewidth',2);
    set(gca,'FontName','CMU Serif');
    set(gca,'FontSize',15);
end
legend('LS','Approx. MLE','CRLB');
%------------- END OF CODE --------------
