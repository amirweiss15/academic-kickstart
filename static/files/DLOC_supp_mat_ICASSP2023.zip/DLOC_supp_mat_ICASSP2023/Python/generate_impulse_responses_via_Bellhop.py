import sys, os
os.environ['PYTHONHASHSEED'] = '0'

import arlpy.uwapm as pm
import numpy as np
import random
import scipy.io as sio
import matplotlib.pyplot as plt

L = 4 # number of sensors
T = 100
fmax = 1000 # [Hz]
w = np.array(range(T))
w = (2*np.pi*fmax*w)/T # frequencies

x_receiver = np.array([[150 , 50 , -50 , -150]]).T # x coordinate of the sensors [m]
y_receiver = np.array([[-250 , -250 , -250 , -250]]).T # y coordinate of the sensors [m]
z_receiver = np.array([[10 , 15 , 20 , 25]]).T # y coordinate of the sensors [m]
p_array = np.array([x_receiver.T, y_receiver.T, z_receiver.T])
p_array = np.squeeze(p_array)

# Environment parameters
scene_id = 1
h = 50 # constant depth all around
ssp = [ # sound speed profile
    [ 0, 1540],  # 1540 m/s at the surface
    [h*0.2, 1530],  # 1530 m/s at 10 m depth
    [h*0.4, 1532],  # 1532 m/s at 20 m depth
    [h*0.7, 1533],  # 1533 m/s at 35 m depth
    [h, 1535],  # 1535 m/s at 50 m depth
]

ssp_mm = [ # sound speed profile                            # mm = mismatch
    [ 0, 1541 + 2*np.random.randn()],  # 1540 m/s at the surface
    [h*0.2, 1528 + 2*np.random.randn()],  # 1530 m/s at 10 m depth
    [h*0.4, 1527 + 2*np.random.randn()],  # 1532 m/s at 20 m depth
    [h*0.7, 1530 + 2*np.random.randn()],  # 1533 m/s at 35 m depth
    [h+1, 1531 + 2*np.random.randn()],  # 1535 m/s at 50 m depth
]

p_source, tau, b, tau_mm, b_mm = [], [], [], [], []

x0 = np.multiply(300,np.random.rand())-150 # true x coordinate of emitters [m]
y0 = np.multiply(100,np.random.rand())-100 # true y coordinate of emitters [m]
z0 = 10 + np.multiply(30,np.random.rand()); # the depth of the source

source_position = np.array( [x0 , y0 , z0] )
p_source = source_position

tau_receivers, b_receivers, tau_receivers_mm, b_receivers_mm = [], [], [], []

freq = 0.005
freq_deviation = freq*(0.5*np.random.rand() - 0.25 )
random_phase = np.multiply(0.05*2*np.pi,np.random.rand())
##################################################################
# For every receiver
for l_ind in range(L):
    rx_l_range = np.linalg.norm(p_array[:,l_ind]-source_position)
    bathy = [
            [0, h],    # depth at the transmitter
            [rx_l_range, h] # depth at the receiver
            ]
    env = pm.create_env2d(
            depth=bathy,
            soundspeed=ssp,
            bottom_soundspeed=1450,
            bottom_density=1200,
            bottom_absorption=1.0,
            frequency=13000,
            rx_depth=np.squeeze(z_receiver)[l_ind],
            rx_range=rx_l_range,
            surface=np.array([[r, 0.5+0.5*np.sin(2*np.pi*freq*r)] for r in np.linspace(0,rx_l_range,1001)]),
            tx_depth=z0)
    arrivals = pm.compute_arrivals(env,model='bellhop')
    tau_receivers.append(arrivals.time_of_arrival.to_numpy())
    b_receivers.append(arrivals.arrival_amplitude.to_numpy())

    ############################################
    # Mismatched environment
    bathy_mm = [
            [0, h],    # depth at the transmitter
            [rx_l_range, h + (np.random.rand()-0.5)] # depth at the receiver
            ]
    env_mm = pm.create_env2d(
            depth=bathy_mm,
            soundspeed=ssp_mm,
            bottom_soundspeed=1450,
            bottom_density=1200,
            bottom_absorption=1.0,
            frequency=13000,
            rx_depth=np.squeeze(z_receiver)[l_ind],
            rx_range=rx_l_range,
            surface=np.array([[r, 0.5+0.5*np.sin(2*np.pi*(freq + freq_deviation)*r + random_phase)] for r in np.linspace(0,rx_l_range,1001)]),
            tx_depth=z0)
    arrivals_mm = pm.compute_arrivals(env_mm,model='bellhop')
    tau_receivers_mm.append(arrivals_mm.time_of_arrival.to_numpy())
    b_receivers_mm.append(arrivals_mm.arrival_amplitude.to_numpy())
    ############################################

##################################################################

# matlab_file_name = f'single_realization_4_matlab_sceneID{scene_id}_E1E2.mat'
# sio.savemat(matlab_file_name, {'Source_Position': p_source, 'TOAs': tau_receivers, 'Attenuation_Coefs': b_receivers, 'TOAs_mm': tau_receivers_mm, 'Attenuation_Coefs_mm': b_receivers_mm})

python_position_file_name = f'Position_single_realization_sceneID{scene_id}_E1.npy'
python_toas_file_name = f'TOAs_single_realization_sceneID{scene_id}_E1.npy'
python_attenuations_file_name = f'Attenuations_single_realization_sceneID{scene_id}_E1.npy'
# Mismatched environment
python_toas_mm_file_name = f'TOAs_single_realization_sceneID{scene_id}_E2.npy'
python_attenuations_mm_file_name = f'Attenuations_single_realization_sceneID{scene_id}_E2.npy'

np.save(python_position_file_name, p_source)
np.save(python_toas_file_name, tau_receivers)
np.save(python_attenuations_file_name, b_receivers)
# Mismatched environment
np.save(python_toas_mm_file_name, tau_receivers_mm)
np.save(python_attenuations_mm_file_name, b_receivers_mm)
np.save(python_attenuations_mm_file_name, b_receivers_mm)