import tensorflow as tf
import tensorflow.keras as k
from tensorflow.keras import layers
from tensorflow.keras.models import Model

import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import time
import pickle
import os

import random 

import direct_localization_model_weights_spherical as loc_est_model
import scipy.io as sio

T = 100
SNR_dB = np.linspace(0,30,20)
SNR_lin = 10**(SNR_dB/10)
L = 4 # number of sensors
fmax = 1000 # [Hz]

fft_coef = 1/( np.sqrt(T) )
ifft_coef = np.sqrt(T)

x_receiver = np.array([[150 , 50 , -50 , -150]]).T # x coordinate of the sensors [m]
y_receiver = np.array([[-250 , -250 , -250 , -250]]).T # y coordinate of the sensors [m]
z_receiver = np.array([[10 , 15 , 20 , 25]]).T # y coordinate of the sensors [m]
p_array = np.array([x_receiver.T, y_receiver.T, z_receiver.T])
p_array = np.squeeze(p_array)

w = np.array(range(T))
w = (2*np.pi*fmax*w)/T # frequencies

positions_file_name = '../positions_training_dataset_sceneID1.npy'
toas_file_name = '../toas_training_dataset_sceneID1.npy'
attenuations_file_name = '../attenuations_Training_dataset_sceneID1.npy'

position_dataset = np.load(positions_file_name,allow_pickle=True)
toas_dataset = np.load(toas_file_name,allow_pickle=True)
attenuations_dataset = np.load(attenuations_file_name,allow_pickle=True)

val_size = 500

position_train_dataset = position_dataset[:,:-val_size,:]
toas_train_dataset = toas_dataset[:,:-val_size,:]
attenuations_train_dataset = attenuations_dataset[:,:-val_size,:]

position_val_dataset = position_dataset[:,-val_size:,:]
toas_val_dataset = toas_dataset[:,-val_size:,:]
attenuations_val_dataset = attenuations_dataset[:,-val_size:,:]

##########################################
N_train = position_train_dataset.shape[1]
all_norm, all_size = [], []
for snr_idx in tqdm(range(np.size(SNR_dB))):
    for idx in range(N_train):
        for l_ind in range(L):
            b = attenuations_train_dataset[snr_idx, idx, l_ind]
            all_norm.append(np.linalg.norm(b))
            all_size.append(b.size)
avg_norm = np.mean(all_norm)
normalization_factor = 1/avg_norm
##########################################


##########################################
# Training data
##########################################

p_source_train, range_source_train, DOA_source_train, phi_source_train = [], [], [], []
X_train = np.zeros( (L,T,N_train,np.size(SNR_dB)),dtype = 'complex_')

X_train_input = np.zeros( (N_train,np.size(SNR_dB),L,T,2), dtype = 'complex_' )
X_train_correlation = np.zeros( ( N_train*np.size(SNR_dB),int((L-1)*L*0.5+L),2*T,2),dtype = 'complex_')

for snr_idx in tqdm(range(np.size(SNR_dB))):
    noise_power = 1/SNR_lin[snr_idx]
    
    for idx in range(N_train):
        source_position = position_train_dataset[snr_idx, idx, :]
        x0 = source_position[0]
        y0 = source_position[1]
        z0 = source_position[2]     
        p_source_train.append(source_position)
        DOA_source_train.append( np.arctan2(source_position[1], source_position[0]) + np.pi ) # in radians
        range_source_train.append( np.linalg.norm(source_position) )
        phi_source_train.append( np.arctan( np.sqrt( y0**2 + x0**2 )/z0 ) ) # in radians

        S = normalization_factor*(np.random.randn(1,T) + np.random.randn(1,T)*1j)/np.sqrt(2)
        for l_ind in range(L):
            b = attenuations_train_dataset[snr_idx, idx, l_ind]
            tau = toas_train_dataset[snr_idx, idx, l_ind]
    
            # CN white noise
            V = np.sqrt(noise_power)*(np.random.randn(1,T) + np.random.randn(1,T)*1j)/np.sqrt(2)
            
            D_and_b = np.matmul( b.T, np.exp(-1j*np.outer(tau,w)) )
            x_bar_l = np.multiply(S,D_and_b) + V
            X_train[l_ind,:,idx,snr_idx] = np.multiply(ifft_coef,np.fft.ifft(x_bar_l)) 
            X_train_input[idx,snr_idx,l_ind,:,0] = np.real(X_train[l_ind,:,idx,snr_idx])
            X_train_input[idx,snr_idx,l_ind,:,1] = np.imag(X_train[l_ind,:,idx,snr_idx])

        counter_ind = 0
        for l1_ind in range(L):
            for l2_ind in range(l1_ind,L):
                X_corr_temp = np.correlate(X_train[l1_ind,:,idx,snr_idx],X_train[l2_ind,:,idx,snr_idx],"full")/T
                X_corr_temp = np.append(X_corr_temp,0)
                X_train_correlation[snr_idx*N_train+idx,counter_ind,:,0] = X_corr_temp.real
                X_train_correlation[snr_idx*N_train+idx,counter_ind,:,1] = X_corr_temp.imag
                counter_ind+=1

p_source_train = np.array(p_source_train)
range_source_train = np.array(range_source_train)
DOA_source_train = np.array(DOA_source_train)
phi_source_train = np.array(phi_source_train)
loc_train = np.column_stack((DOA_source_train,range_source_train,phi_source_train))

##########################################
# Validation data
##########################################
N_val = val_size

p_source_val, range_source_val, DOA_source_val, phi_source_val = [], [], [], []
X_val = np.zeros( (L,T,N_val,np.size(SNR_dB)),dtype = 'complex_')
X_val_input = np.zeros( (N_val,np.size(SNR_dB),L,T,2), dtype = 'complex_' )
X_val_correlation = np.zeros( ( N_val*np.size(SNR_dB),int((L-1)*L*0.5+L),2*T,2),dtype = 'complex_')

for snr_idx in tqdm(range(np.size(SNR_dB))):
    noise_power = 1/SNR_lin[snr_idx]
    
    for idx in range(N_val):
        source_position = position_val_dataset[snr_idx, idx, :]
        x0 = source_position[0]
        y0 = source_position[1]
        z0 = source_position[2]
        p_source_val.append(source_position)
        phi_source_val.append( np.arctan( np.sqrt( y0**2 + x0**2 )/z0 ) ) # in radians
        DOA_source_val.append( np.arctan2(source_position[1], source_position[0]) + np.pi ) # in radians
        range_source_val.append( np.linalg.norm(source_position) )

        S = normalization_factor*(np.random.randn(1,T) + np.random.randn(1,T)*1j)/np.sqrt(2)
        for l_ind in range(L):
            b = attenuations_val_dataset[snr_idx, idx, l_ind]
            # b = np.sqrt(np.size(b))*(b/np.linalg.norm(b))
            tau = toas_val_dataset[snr_idx, idx, l_ind]
    
            # CN white noise
            V = np.sqrt(noise_power)*(np.random.randn(1,T) + np.random.randn(1,T)*1j)/np.sqrt(2)
            
            D_and_b = np.matmul( b.T, np.exp(-1j*np.outer(tau,w)) )
            x_bar_l = np.multiply(S,D_and_b) + V
            X_val[l_ind,:,idx,snr_idx] = np.multiply(ifft_coef,np.fft.ifft(x_bar_l)) 
            X_val_input[idx,snr_idx,l_ind,:,0] = np.real(X_val[l_ind,:,idx,snr_idx])
            X_val_input[idx,snr_idx,l_ind,:,1] = np.imag(X_val[l_ind,:,idx,snr_idx])

        counter_ind = 0
        for l1_ind in range(L):
            for l2_ind in range(l1_ind,L):
                X_corr_temp = np.correlate(X_val[l1_ind,:,idx,snr_idx],X_val[l2_ind,:,idx,snr_idx],"full")/T
                X_corr_temp = np.append(X_corr_temp,0)
                X_val_correlation[snr_idx*N_val+idx,counter_ind,:,0] = X_corr_temp.real
                X_val_correlation[snr_idx*N_val+idx,counter_ind,:,1] = X_corr_temp.imag
                counter_ind+=1

p_source_val = np.array(p_source_val)
range_source_val = np.array(range_source_val)
DOA_source_val = np.array(DOA_source_val)
phi_source_val = np.array(phi_source_val)
loc_val = np.column_stack((DOA_source_val,range_source_val,phi_source_val))
##########################################

num_of_epochs = 100

shape_vector = X_train_correlation.shape
input_shape = shape_vector[1:]
k_sz = 3
long_k_sz = T

checkpoint_filepath = './tmp_DLOC_model_bellhop_ID1_batchV2/checkpoint'

model_checkpoint_callback = tf.keras.callbacks.ModelCheckpoint(
    filepath=checkpoint_filepath,
    save_weights_only=True,
    monitor='val_loss',
    mode='min',
    save_best_only=True)


nn_model = loc_est_model.get_DLOC_model_weight_spherical(input_shape, L, k_sz, long_k_sz, lr=0.0001)

nn_model.fit(X_train_correlation, loc_train, validation_data=(X_val_correlation,loc_val), epochs=num_of_epochs, batch_size=30, shuffle=True, verbose=1, callbacks=[model_checkpoint_callback])

nn_model.save_weights("DLOC_model_bellhop_ID1_weights_batchV2")