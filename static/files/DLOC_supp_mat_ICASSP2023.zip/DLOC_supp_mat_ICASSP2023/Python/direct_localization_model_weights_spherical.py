import tensorflow as tf
import tensorflow.keras as k
from tensorflow.keras import layers
from tensorflow.keras.models import Model

import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import time
import pickle
import os


def DOA_loss_fn(y_true, y_pred):
    cyclic_error = 2 - 2*tf.math.cos( (y_pred - y_true) )
    return tf.reduce_mean(cyclic_error, axis=-1)  # Note the `axis=-1`


def Elevation_my_loss_fn(y_true, y_pred):
    cyclic_error = 2 - 2*tf.math.cos( 2*(y_pred - y_true) )
    return tf.reduce_mean(cyclic_error, axis=-1)  # Note the `axis=-1`


def direct_localization_loss_fn_spherical(y_true, y_pred):
    
    DOA_true = y_true[:,0]
    Range_true = y_true[:,1]
    Elevation_true = y_true[:,2]
    
    DOA_pred = y_pred[:,0]
    Range_pred = y_pred[:,1]
    Elevation_pred = y_pred[:,2]
    
    term_A = tf.math.sin(Elevation_true)*tf.math.sin(Elevation_pred)*tf.math.cos(DOA_true-DOA_pred)
    
    term_B = tf.math.cos(Elevation_true)*tf.math.cos(Elevation_pred)
    
    sum_terms_A_B = term_A + term_B
    
    spherical_distance_square = tf.math.square(Range_true) + tf.math.square(Range_pred) - 2*Range_true*Range_pred*sum_terms_A_B
    
    return tf.reduce_mean(spherical_distance_square, axis=-1)  # Note the `axis=-1`


def get_custom_model_range_est(in0, input_shape, T, k_sz=3, long_k_sz=101, lr=0.0003):

    start_neurons = 8

    num_of_functions = input_shape[0]

    x = in0
    x = layers.BatchNormalization()(x)

    # 200
    conv1 = layers.Conv2D(T, (num_of_functions, long_k_sz), activation="relu", padding="same")(x)
    conv1 = layers.Conv2D(T, (num_of_functions, long_k_sz), activation="relu", padding="same")(conv1)
    conv1 = layers.Conv2D(start_neurons * 8, (num_of_functions, k_sz), activation="relu", padding="same")(conv1)
    pool1 = layers.AveragePooling2D((1, 2))(conv1)
    pool1 = layers.Dropout(0.5)(pool1)

    # 100
    conv2 = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(pool1)
    conv2 = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(conv2)
    pool2 = layers.AveragePooling2D((1, 2))(conv2)
    pool2 = layers.Dropout(0.5)(pool2)

    # 50
    conv3 = layers.Conv2D(start_neurons * 4, (k_sz, k_sz), activation="relu", padding="same")(pool2)
    conv3 = layers.Conv2D(start_neurons * 4, (k_sz, k_sz), activation="relu", padding="same")(conv3)
    pool3 = layers.AveragePooling2D((1, 2))(conv3)
    pool3 = layers.Dropout(0.5)(pool3)


    # 25
    conv4 = layers.Conv2D(start_neurons * 2, (k_sz, k_sz), activation="relu", padding="same")(pool3)
    conv4 = layers.Conv2D(start_neurons * 2, (k_sz, k_sz), activation="relu", padding="same")(conv4)
    pool4 = layers.AveragePooling2D((1, 2))(conv4)
    pool4 = layers.Dropout(0.5)(pool4)

    # 12
    convm = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(pool4)
    convm = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(convm)
    poolm = layers.AveragePooling2D((1, 2))(convm)

    # 3
    two_before_output_layer = layers.Flatten()(poolm)
    one_before_output_layer = layers.Dense(10,activation='relu')(two_before_output_layer)
    output_layer = layers.Dense(1,activation='relu')(one_before_output_layer)
    x_out_range = output_layer

    supreg_net = Model(in0, x_out_range, name='supreg')

    supreg_net.compile(optimizer=k.optimizers.Adam(learning_rate=lr),
              loss=tf.keras.losses.MeanSquaredError(),
              metrics=[tf.keras.losses.MeanSquaredError()])
    
    return supreg_net, x_out_range, one_before_output_layer


def get_custom_model_DOA_est_MCE(in0, input_shape, T, k_sz=3, long_k_sz=101, lr=0.0003):
    
    start_neurons = 8

    num_of_functions = input_shape[0]

    x = in0
    x = layers.BatchNormalization()(x)

    # 200
    conv1 = layers.Conv2D(T, (num_of_functions, long_k_sz), activation="relu", padding="same")(x)
    conv1 = layers.Conv2D(T, (num_of_functions, long_k_sz), activation="relu", padding="same")(conv1)
    conv1 = layers.Conv2D(start_neurons * 8, (num_of_functions, k_sz), activation="relu", padding="same")(conv1)
    pool1 = layers.AveragePooling2D((1, 2))(conv1)
    pool1 = layers.Dropout(0.5)(pool1)

    # 100
    conv2 = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(pool1)
    conv2 = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(conv2)
    pool2 = layers.AveragePooling2D((1, 2))(conv2)
    pool2 = layers.Dropout(0.5)(pool2)

    # 50
    conv3 = layers.Conv2D(start_neurons * 4, (k_sz, k_sz), activation="relu", padding="same")(pool2)
    conv3 = layers.Conv2D(start_neurons * 4, (k_sz, k_sz), activation="relu", padding="same")(conv3)
    pool3 = layers.AveragePooling2D((1, 2))(conv3)
    pool3 = layers.Dropout(0.5)(pool3)


    # 25
    conv4 = layers.Conv2D(start_neurons * 2, (k_sz, k_sz), activation="relu", padding="same")(pool3)
    conv4 = layers.Conv2D(start_neurons * 2, (k_sz, k_sz), activation="relu", padding="same")(conv4)
    pool4 = layers.AveragePooling2D((1, 2))(conv4)
    pool4 = layers.Dropout(0.5)(pool4)

    # 12
    convm = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(pool4)
    convm = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(convm)
    poolm = layers.AveragePooling2D((1, 2))(convm)

    # 3
    two_before_output_layer = layers.Flatten()(poolm)
    one_before_output_layer = layers.Dense(10,activation='relu')(two_before_output_layer)
    output_layer = layers.Dense(1,activation='relu')(one_before_output_layer)
    x_out_DOA = output_layer

    supreg_net = Model(in0, x_out_DOA, name='supreg')
    
    supreg_net.compile(optimizer=k.optimizers.Adam(learning_rate=lr),
              loss=DOA_loss_fn,
              metrics=[tf.keras.losses.MeanSquaredError()])
    
    return supreg_net, x_out_DOA, one_before_output_layer


def get_custom_model_Elevation_est_MCE(in0, input_shape, T, k_sz=3, long_k_sz=101, lr=0.0003):

    start_neurons = 8

    num_of_functions = input_shape[0]

    x = in0
    x = layers.BatchNormalization()(x)

    # 200
    conv1 = layers.Conv2D(T, (num_of_functions, long_k_sz), activation="relu", padding="same")(x)
    conv1 = layers.Conv2D(T, (num_of_functions, long_k_sz), activation="relu", padding="same")(conv1)
    conv1 = layers.Conv2D(start_neurons * 8, (num_of_functions, k_sz), activation="relu", padding="same")(conv1)
    pool1 = layers.AveragePooling2D((1, 2))(conv1)
    pool1 = layers.Dropout(0.5)(pool1)

    # 100
    conv2 = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(pool1)
    conv2 = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(conv2)
    pool2 = layers.AveragePooling2D((1, 2))(conv2)
    pool2 = layers.Dropout(0.5)(pool2)

    # 50
    conv3 = layers.Conv2D(start_neurons * 4, (k_sz, k_sz), activation="relu", padding="same")(pool2)
    conv3 = layers.Conv2D(start_neurons * 4, (k_sz, k_sz), activation="relu", padding="same")(conv3)
    pool3 = layers.AveragePooling2D((1, 2))(conv3)
    pool3 = layers.Dropout(0.5)(pool3)


    # 25
    conv4 = layers.Conv2D(start_neurons * 2, (k_sz, k_sz), activation="relu", padding="same")(pool3)
    conv4 = layers.Conv2D(start_neurons * 2, (k_sz, k_sz), activation="relu", padding="same")(conv4)
    pool4 = layers.AveragePooling2D((1, 2))(conv4)
    pool4 = layers.Dropout(0.5)(pool4)

    # 12
    convm = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(pool4)
    convm = layers.Conv2D(start_neurons * 8, (k_sz, k_sz), activation="relu", padding="same")(convm)
    poolm = layers.AveragePooling2D((1, 2))(convm)

    # 3
    two_before_output_layer = layers.Flatten()(poolm)
    one_before_output_layer = layers.Dense(10,activation='relu')(two_before_output_layer)
    output_layer = layers.Dense(1,activation='relu')(one_before_output_layer)
    x_out_elevation = output_layer

    supreg_net = Model(in0, x_out_elevation, name='supreg')

    supreg_net.compile(optimizer=k.optimizers.Adam(learning_rate=lr),
              loss=Elevation_my_loss_fn,
              metrics=[tf.keras.losses.MeanSquaredError()])
    
    return supreg_net, x_out_elevation, one_before_output_layer


def get_DLOC_model_weight_spherical(input_shape, L, k_sz=3, long_k_sz=101, lr=0.0003):
    
    in0 = layers.Input(shape=input_shape)
    
    long_k_sz_in = long_k_sz
    
    DOA_model, DOA_out, one_before_output_layer_DOA = get_custom_model_DOA_est_MCE(in0, input_shape, L, k_sz=3, long_k_sz=long_k_sz_in, lr=0.0003)
    Range_model, Range_out, one_before_output_layer_Range = get_custom_model_range_est(in0, input_shape, L, k_sz=3, long_k_sz=long_k_sz_in, lr=0.0003)
    Elevation_model, Elevation_out, one_before_output_layer_Elevation = get_custom_model_Elevation_est_MCE(in0, input_shape, L, k_sz=3, long_k_sz=long_k_sz_in, lr=0.0003)
    
    DOA_model.load_weights('DOA_model_bellhop_ID1_weights_batchV2b')
    Range_model.load_weights('range_model_bellhop_ID1_weights_batchV2b')
    Elevation_model.load_weights('Elevation_model_bellhop_ID1_weights_batchV2b')
    
    location_est = layers.Concatenate(axis=-1)([DOA_out, Range_out, Elevation_out])
    
    x_out = location_est

    supreg_net = Model(in0, x_out, name='supreg')
    
    supreg_net.compile(optimizer=k.optimizers.Adam(learning_rate=lr),
              loss=direct_localization_loss_fn_spherical,
              metrics=[tf.keras.losses.MeanSquaredError()])
    
    return supreg_net

