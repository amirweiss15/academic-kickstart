import tensorflow as tf
import tensorflow.keras as k
from tensorflow.keras import layers
from tensorflow.keras.models import Model

import numpy as np
import matplotlib.pyplot as plt
from tqdm import tqdm
import time
import pickle
import os

import random 
import tensorflow as tf
from tqdm import tqdm

import sys
sys.path.insert(0, '/home/gridsan/amirwei/TFO_Project/LocalizationNN/Bellhop_environments/environment_ID1/DLOC/V2/')
import direct_localization_model_weights_spherical as loc_est_model
import scipy.io as sio


T = 100
SNR_dB = np.linspace(-15,15,30)
SNR_lin = 10**(SNR_dB/10)
# noise_power = 1/SNR_lin
L = 4 # number of sensors
fmax = 1000 # [Hz]

fft_coef = 1/( np.sqrt(T) )
ifft_coef = np.sqrt(T)

x_receiver = np.array([[150 , 50 , -50 , -150]]).T # x coordinate of the sensors [m]
y_receiver = np.array([[-250 , -250 , -250 , -250]]).T # y coordinate of the sensors [m]
z_receiver = np.array([[10 , 15 , 20 , 25]]).T # y coordinate of the sensors [m]
p_array = np.array([x_receiver.T, y_receiver.T, z_receiver.T])
p_array = np.squeeze(p_array)

w = np.array(range(T))
w = (2*np.pi*fmax*w)/T # frequencies

position_file_name = '/home/gridsan/amirwei/TFO_Project/LocalizationNN/Bellhop_environments/environment_ID1_mismatch_single_realization/generate_scenario/G/Position_single_realization_sceneID1_E1.npy'
toas_file_name = '/home/gridsan/amirwei/TFO_Project/LocalizationNN/Bellhop_environments/environment_ID1_mismatch_single_realization/generate_scenario/G/TOAs_single_realization_sceneID1_E1.npy'
attenuations_file_name = '/home/gridsan/amirwei/TFO_Project/LocalizationNN/Bellhop_environments/environment_ID1_mismatch_single_realization/generate_scenario/G/Attenuations_single_realization_sceneID1_E1.npy'
# Mismatch
toas_mm_file_name = '/home/gridsan/amirwei/TFO_Project/LocalizationNN/Bellhop_environments/environment_ID1_mismatch_single_realization/generate_scenario/G/TOAs_single_realization_sceneID1_E2.npy'
attenuations_mm_file_name = '/home/gridsan/amirwei/TFO_Project/LocalizationNN/Bellhop_environments/environment_ID1_mismatch_single_realization/generate_scenario/G/Attenuations_single_realization_sceneID1_E2.npy'

#####################################################################
source_position = np.load(position_file_name,allow_pickle=True)
x0 = source_position[0]
y0 = source_position[1]
z0 = source_position[2]
range_source_test = np.linalg.norm([x0 , y0 , z0])
DOA_source_test = ( np.arctan2(y0, x0) + np.pi )
phi_source_test = ( np.arctan( np.sqrt( y0**2 + x0**2 )/z0 ) )
#####################################################################

toas_test = np.load(toas_file_name,allow_pickle=True)
attenuations_test = np.load(attenuations_file_name,allow_pickle=True)
# Mismatch
toas_mm_test = np.load(toas_mm_file_name,allow_pickle=True)
attenuations_mm_test = np.load(attenuations_mm_file_name,allow_pickle=True)

##########################################
# N_test = position_test_dataset.shape[1]
# all_norm, all_size = [], []
# for snr_idx in tqdm(range(np.size(SNR_dB))):
#     for idx in range(N_test):
#         for l_ind in range(L):
#             b = attenuations_test_dataset[snr_idx, idx, l_ind]
#             all_norm.append(np.linalg.norm(b))
#             all_size.append(b.size)
# avg_norm = np.mean(all_norm)
# normalization_factor = 1/avg_norm
normalization_factor = 168.2622
##########################################

input_shape = np.array( [int((L-1)*L*0.5+L), 2*T, 2] )
k_sz = 3
long_k_sz = T

nn_model = loc_est_model.get_DLOC_model_weight_spherical(input_shape, L, k_sz, long_k_sz)
nn_model.load_weights("DLOC_model_bellhop_ID1_weights_batchV2")

##########################################
# Import recorded noise
##########################################
# For the real ocean recorded noise, please email me to request the data
#
# Import recorded noise from KAM11
# V_recorded_mat = np.load('noise_KAM11_1kHz_at_13kHz.npy')
# num_of_files, num_of_channels, num_of_samp = V_recorded_mat.shape

##########################################
# Testing data
##########################################
# N_test = attenuations_test_dataset.shape[1]
# N_test = 10000
N_test = 10

# p_source_test = np.zeros( (N_test,np.size(SNR_dB),3) )
# range_source_test = np.zeros( (N_test,np.size(SNR_dB),1) )
# DOA_source_test = np.zeros( (N_test,np.size(SNR_dB),1) )
# phi_source_test = np.zeros( (N_test,np.size(SNR_dB),1) )
X_test = np.zeros( (L,T,N_test,np.size(SNR_dB)),dtype = 'complex_')
X_test_input = np.zeros( (N_test,np.size(SNR_dB),L,T,2), dtype = 'complex_' )
X_test_correlation = np.zeros( ( N_test,np.size(SNR_dB),int((L-1)*L*0.5+L),2*T,2),dtype = 'complex_')
# Mismatch
X_test_mm = np.zeros( (L,T,N_test,np.size(SNR_dB)),dtype = 'complex_')
X_test_input_mm = np.zeros( (N_test,np.size(SNR_dB),L,T,2), dtype = 'complex_' )
X_test_correlation_mm = np.zeros( ( N_test,np.size(SNR_dB),int((L-1)*L*0.5+L),2*T,2),dtype = 'complex_')

for snr_idx in tqdm(range(np.size(SNR_dB))):
    noise_power = 1/SNR_lin[snr_idx]
    
    for idx in range(N_test):
#         source_position = position_test_dataset[snr_idx, idx, :]
#         x0 = source_position[0]
#         y0 = source_position[1]
#         z0 = source_position[2]

#         range_source_test[idx,snr_idx,0] = np.linalg.norm([x0 , y0 , z0])
#         DOA_source_test[idx,snr_idx,0] = ( np.arctan2(y0, x0) + np.pi )
#         phi_source_test[idx,snr_idx,0] = ( np.arctan( np.sqrt( y0**2 + x0**2 )/z0 ) )

        S = normalization_factor*(np.random.randn(1,T) + np.random.randn(1,T)*1j)/np.sqrt(2)
        for l_ind in range(L):
            
            b = attenuations_test[l_ind]
            tau = toas_test[l_ind]
            
            # Mismatch
            b_mm = attenuations_mm_test[l_ind]
            tau_mm = toas_mm_test[l_ind]
            
#             file_ind = np.random.randint(2)+(num_of_files-4)
#             channel_ind = np.random.randint(2)+num_of_channels-2
#             start_ind_rec = np.random.randint(num_of_samp-101)
#             V_selected = V_recorded_mat[file_ind,channel_ind,start_ind_rec:start_ind_rec+T]
#             V_selected_norm = V_selected/np.std(V_selected)
#             V = ( np.sqrt(noise_power)*V_selected_norm )/np.sqrt(2)
            
            # CN white noise
            V = np.sqrt(noise_power)*(np.random.randn(1,T) + np.random.randn(1,T)*1j)/np.sqrt(2)
            
            D_and_b = np.matmul( b.T, np.exp(-1j*np.outer(tau,w)) )
            x_bar_l = np.multiply(S,D_and_b) + V
            X_test[l_ind,:,idx,snr_idx] = np.multiply(ifft_coef,np.fft.ifft(x_bar_l)) 
            X_test_input[idx,snr_idx,l_ind,:,0] = np.real(X_test[l_ind,:,idx,snr_idx])
            X_test_input[idx,snr_idx,l_ind,:,1] = np.imag(X_test[l_ind,:,idx,snr_idx])
            
            # Mismatch
            D_and_b_mm = np.matmul( b_mm.T, np.exp(-1j*np.outer(tau_mm,w)) )
            x_bar_l_mm = np.multiply(S,D_and_b_mm) + V
            X_test_mm[l_ind,:,idx,snr_idx] = np.multiply(ifft_coef,np.fft.ifft(x_bar_l_mm)) 
            X_test_input_mm[idx,snr_idx,l_ind,:,0] = np.real(X_test_mm[l_ind,:,idx,snr_idx])
            X_test_input_mm[idx,snr_idx,l_ind,:,1] = np.imag(X_test_mm[l_ind,:,idx,snr_idx])

        counter_ind = 0
        for l1_ind in range(L):
            for l2_ind in range(l1_ind,L):
                X_corr_temp = np.correlate(X_test[l1_ind,:,idx,snr_idx],X_test[l2_ind,:,idx,snr_idx],"full")/T
                X_corr_temp = np.append(X_corr_temp,0)
                X_test_correlation[idx,snr_idx,counter_ind,:,0] = X_corr_temp.real
                X_test_correlation[idx,snr_idx,counter_ind,:,1] = X_corr_temp.imag
                # Mismatch
                X_corr_temp_mm = np.correlate(X_test_mm[l1_ind,:,idx,snr_idx],X_test_mm[l2_ind,:,idx,snr_idx],"full")/T
                X_corr_temp_mm = np.append(X_corr_temp_mm,0)
                X_test_correlation_mm[idx,snr_idx,counter_ind,:,0] = X_corr_temp_mm.real
                X_test_correlation_mm[idx,snr_idx,counter_ind,:,1] = X_corr_temp_mm.imag
                counter_ind+=1
                
error_test_set = np.zeros( (N_test,3,np.size(SNR_dB)) )
# Mismatch
error_test_set_mm = np.zeros( (N_test,3,np.size(SNR_dB)) )

for idx_snr in tqdm(range(np.size(SNR_dB))):
    for idx_test in range(N_test):
        X_test_sample_valid = np.expand_dims(X_test_correlation[idx_test,idx_snr,:], axis=0)
        location_est_test = np.squeeze(nn_model.predict(X_test_sample_valid))
        
        # error_test_set[idx_test,0,idx_snr] = np.mod(location_est_test[0],2*np.pi)-DOA_source_test
        # error_test_set[idx_test,1,idx_snr] = location_est_test[1]-range_source_test
        # error_test_set[idx_test,2,idx_snr] = ( np.mod(location_est_test[2]+np.pi/2,np.pi)-np.pi/2 )-phi_source_test
        
        range_est_test = location_est_test[1]
        DOA_est_test = np.mod(location_est_test[0],2*np.pi) - np.pi
        phi_est_test = ( np.mod(location_est_test[2]+np.pi/2,np.pi)-np.pi/2 )
        # Convert to cartesian coordinates
        x_est_test = range_est_test*np.cos( DOA_est_test )*np.sin( phi_est_test )
        y_est_test = range_est_test*np.sin( DOA_est_test )*np.sin( phi_est_test )
        z_est_test = range_est_test*np.cos( phi_est_test )
       
        # # Fix DOA according to prior
        # if x_est_test>150:
        #     x_est_test = 150
        # if x_est_test<-150:
        #     x_est_test = -150
        # if y_est_test>0:
        #     y_est_test = 0
        # if y_est_test<-100:
        #     y_est_test = -100
        # if z_est_test>40:
        #     z_est_test = 40
        # if z_est_test<10:
        #     z_est_test = 10
        
        range_est_test_fixed = np.linalg.norm([x_est_test , y_est_test , z_est_test])
        DOA_est_test_fixed = np.arctan2(y_est_test, x_est_test) + np.pi
        phi_est_test_fixed = np.arctan( np.sqrt( y_est_test**2 + x_est_test**2 )/z_est_test )
        error_test_set[idx_test,0,idx_snr] = DOA_est_test_fixed-DOA_source_test
        error_test_set[idx_test,1,idx_snr] = range_est_test_fixed-range_source_test
        error_test_set[idx_test,2,idx_snr] = ( np.mod(phi_est_test_fixed+np.pi/2,np.pi)-np.pi/2 )-phi_source_test
        
        # Mismatch
        X_test_sample_valid_mm = np.expand_dims(X_test_correlation_mm[idx_test,idx_snr,:], axis=0)
        location_est_test_mm = np.squeeze(nn_model.predict(X_test_sample_valid_mm))
        
        # error_test_set_mm[idx_test,0,idx_snr] = np.mod(location_est_test_mm[0],2*np.pi)-DOA_source_test
        # error_test_set_mm[idx_test,1,idx_snr] = location_est_test_mm[1]-range_source_test
        # error_test_set_mm[idx_test,2,idx_snr] = ( np.mod(location_est_test_mm[2]+np.pi/2,np.pi)-np.pi/2 )-phi_source_test
        
        range_est_test_mm = location_est_test_mm[1]
        DOA_est_test_mm = np.mod(location_est_test_mm[0],2*np.pi) - np.pi
        phi_est_test_mm = ( np.mod(location_est_test_mm[2]+np.pi/2,np.pi)-np.pi/2 )
        # Convert to cartesian coordinates
        x_est_test_mm = range_est_test_mm*np.cos( DOA_est_test_mm )*np.sin( phi_est_test_mm )
        y_est_test_mm = range_est_test_mm*np.sin( DOA_est_test_mm )*np.sin( phi_est_test_mm )
        z_est_test_mm = range_est_test_mm*np.cos( phi_est_test_mm )
        
        # # Fix DOA according to prior
        # if x_est_test_mm>150:
        #     x_est_test_mm = 150
        # if x_est_test_mm<-150:
        #     x_est_test_mm = -150
        # if y_est_test_mm>0:
        #     y_est_test_mm = 0
        # if y_est_test_mm<-100:
        #     y_est_test_mm = -100
        # if z_est_test_mm>40:
        #     z_est_test_mm = 40
        # if z_est_test_mm<10:
        #     z_est_test_mm = 10
            
        range_est_test_fixed_mm = np.linalg.norm([x_est_test_mm , y_est_test_mm , z_est_test_mm])
        DOA_est_test_fixed_mm = np.arctan2(y_est_test_mm, x_est_test_mm) + np.pi
        phi_est_test_fixed_mm = np.arctan( np.sqrt( y_est_test_mm**2 + x_est_test_mm**2 )/z_est_test_mm )
        error_test_set_mm[idx_test,0,idx_snr] = np.mod(DOA_est_test_fixed_mm,2*np.pi)-DOA_source_test
        error_test_set_mm[idx_test,1,idx_snr] = range_est_test_fixed_mm-range_source_test
        error_test_set_mm[idx_test,2,idx_snr] = ( np.mod(phi_est_test_fixed_mm+np.pi/2,np.pi)-np.pi/2 )-phi_source_test
##########################################

np.save('error_test_single_realization_bellhop_model_ID1E1_mm_batch_G.npy', error_test_set)
np.save('error_test_single_realization_bellhop_model_ID1E2_mm2_batch_G.npy', error_test_set_mm)

location_est_test_matrix = np.zeros( (np.size(SNR_dB),N_test,3 ) )
for idx_snr in tqdm(range(np.size(SNR_dB))):
    for idx_test in range(N_test):
        location_est_test_matrix[idx_snr,idx_test,0] = error_test_set[idx_test,0,idx_snr] + DOA_source_test
        location_est_test_matrix[idx_snr,idx_test,1] = error_test_set[idx_test,1,idx_snr] + range_source_test
        location_est_test_matrix[idx_snr,idx_test,2] = error_test_set[idx_test,2,idx_snr] + phi_source_test

np.save('location_est_test_single_realization_matrix_bellhop_model_ID1E1_mm_batch_G.npy', location_est_test_matrix)

# Mismatch
location_est_test_matrix_mm = np.zeros( (np.size(SNR_dB),N_test,3 ) )
for idx_snr in tqdm(range(np.size(SNR_dB))):
    for idx_test in range(N_test):
        location_est_test_matrix_mm[idx_snr,idx_test,0] = error_test_set_mm[idx_test,0,idx_snr] + DOA_source_test
        location_est_test_matrix_mm[idx_snr,idx_test,1] = error_test_set_mm[idx_test,1,idx_snr] + range_source_test
        location_est_test_matrix_mm[idx_snr,idx_test,2] = error_test_set_mm[idx_test,2,idx_snr] + phi_source_test
        
np.save('location_est_test_single_realization_matrix_bellhop_model_ID1E2_mm2_batch_G.npy', location_est_test_matrix_mm)

squared_error_position = np.zeros( (np.size(SNR_dB),N_test ) )
for idx_snr in tqdm(range(np.size(SNR_dB))):
    for idx_test in range(N_test):
        est_DOA = location_est_test_matrix[idx_snr,idx_test,0]
        est_range = location_est_test_matrix[idx_snr,idx_test,1]
        est_elevation = location_est_test_matrix[idx_snr,idx_test,2]
        
        true_DOA = DOA_source_test
        true_range = range_source_test
        true_elevation = phi_source_test
        
        termA = np.sin(true_elevation)*np.sin(est_elevation)*np.cos(true_DOA-est_DOA)
        termB = np.cos(true_elevation)*np.cos(est_elevation)
        
        squared_error_position[idx_snr,idx_test] = est_range**2 + true_range**2 -2*est_range*true_range*( termA + termB )

RMSE_position = np.sqrt(np.mean( squared_error_position, axis=1 ))
var_sqrd_err = np.var( squared_error_position, axis=1 )
np.save('DLOC_RMSE_vs_SNR_bellhop_model_single_realization_ID1E1_mm_batch_G.npy', RMSE_position)
np.save('DLOC_var_sqrd_err_vs_SNR_bellhop_model_single_realization_ID1E1_mm_batch_G.npy', var_sqrd_err)

# Mismatch
squared_error_position_mm = np.zeros( (np.size(SNR_dB),N_test ) )
for idx_snr in tqdm(range(np.size(SNR_dB))):
    for idx_test in range(N_test):
        est_DOA_mm = location_est_test_matrix_mm[idx_snr,idx_test,0]
        est_range_mm = location_est_test_matrix_mm[idx_snr,idx_test,1]
        est_elevation_mm = location_est_test_matrix_mm[idx_snr,idx_test,2]
        
        true_DOA = DOA_source_test
        true_range = range_source_test
        true_elevation = phi_source_test
        
        termA_mm = np.sin(true_elevation)*np.sin(est_elevation_mm)*np.cos(true_DOA-est_DOA_mm)
        termB_mm = np.cos(true_elevation)*np.cos(est_elevation_mm)
        
        squared_error_position_mm[idx_snr,idx_test] = est_range_mm**2 + true_range**2 -2*est_range_mm*true_range*( termA_mm + termB_mm )
        
RMSE_position_mm = np.sqrt(np.mean( squared_error_position_mm, axis=1 ))
var_sqrd_err_mm = np.var( squared_error_position_mm, axis=1 )
np.save('DLOC_RMSE_vs_SNR_bellhop_model_single_realization_ID1E2_mm2_batch_G.npy', RMSE_position_mm)
np.save('DLOC_var_sqrd_err_vs_SNR_bellhop_model_single_realization_ID1E2_mm_batch_G.npy', var_sqrd_err_mm)


plt.rcParams["text.usetex"] = True
plt.rcParams["mathtext.fontset"] = "cm"
plt.rcParams.update({
    'font.size': 8.0,
    'text.usetex': True,
    'text.latex.preamble': r'\usepackage{amsfonts}'
})

fig, ax = plt.subplots(figsize=(6.0, 4.0), tight_layout=True)
ax.plot(SNR_dB,RMSE_position,label="Matched")
ax.plot(SNR_dB,RMSE_position_mm,label="Mismatched")
# ax.plot(SNR_dB, std_vec_1bit,label="1-bit quantization")
plt.legend(loc='upper right', fontsize=14)

# textstr = '0\% perturbations \n in surface time-delay'
# props = dict(boxstyle='round', facecolor='white', alpha=0.8)
# place a text box in upper left in axes coords
# ax.text(0.65, 0.7, textstr, transform=ax.transAxes, fontsize=14,
#         verticalalignment='top', bbox=props)

ax.grid()

ax.set_xlabel('SNR [dB]', fontsize=14)
ax.set_ylabel(r'$\sqrt{\mathbb{E}[\varepsilon^2]}$ [m]', fontsize=14)
ax.set_title(r'Location RMSE vs. SNR, $L=4$ sensors, $T=100$ samples', fontsize=14)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
fig
fig.savefig('DLOC_RMSE_vs_SNR_bellhop_env_single_realization_ID1_mm2_batch_G.png')

##################################################################
# Upper Bound
H = np.zeros( (L,T), dtype = 'complex_')
H_mm = np.zeros( (L,T), dtype = 'complex_' )

for l_ind in range(L):
    H[l_ind,:] = np.matmul( attenuations_test[l_ind].T, np.exp(-1j*np.outer(toas_test[l_ind],w)) )
    H_mm[l_ind,:] = np.matmul( attenuations_mm_test[l_ind].T, np.exp(-1j*np.outer(toas_mm_test[l_ind],w)) )

h_bar_sqrd_norm = np.zeros( (T) )
h_bar_sqrd_norm_mm = np.zeros( (T) )
for k_ind in range(T):
    h_bar_sqrd_norm[k_ind] = np.linalg.norm( H[:,k_ind] )**2
    h_bar_sqrd_norm_mm[k_ind] = np.linalg.norm( H_mm[:,k_ind] )**2

noise_power = 1/SNR_lin

SNR_lin_updated = (normalization_factor**2)*SNR_lin

chi_sqr_div_per_snr = np.zeros( (np.size(SNR_dB)) )
for snr_idx in range(np.size(SNR_dB)):
    condition_chi_sqr_div_per_snr = 2*h_bar_sqrd_norm + 1/SNR_lin_updated[0] > h_bar_sqrd_norm_mm
    if np.alltrue(condition_chi_sqr_div_per_snr):
        numerator = ( (normalization_factor**2)*h_bar_sqrd_norm + noise_power[snr_idx] )**2
        denominator = ( (normalization_factor**2)*h_bar_sqrd_norm_mm + noise_power[snr_idx] )*( (normalization_factor**2)*(2*h_bar_sqrd_norm - h_bar_sqrd_norm_mm) + noise_power[snr_idx] )
        chi_sqr_div_per_snr[snr_idx] = np.prod( numerator/denominator ) - 1
    else:
        print(f'Chi-square divergence not met for SNR index {snr_idx}')
        
RMSE_upper_bound = np.sqrt( np.mean( squared_error_position, axis=1 ) + np.sqrt( np.var( squared_error_position, axis=1 )*chi_sqr_div_per_snr ) )
RMSE_of_mean_est = np.sqrt((300**2)/12 + (100**2)/12 + (30**2)/12)
RMSE_upper_bound_with_prior = np.minimum( RMSE_upper_bound, RMSE_of_mean_est )

plt.rcParams["text.usetex"] = True
plt.rcParams["mathtext.fontset"] = "cm"
plt.rcParams.update({
    'font.size': 8.0,
    'text.usetex': True,
    'text.latex.preamble': r'\usepackage{amsfonts}'
})

fig2, ax2 = plt.subplots(figsize=(6.0, 4.0), tight_layout=True)
ax2.plot(SNR_dB,RMSE_position,label="Matched")
ax2.plot(SNR_dB,RMSE_position_mm,label="Mismatched")
ax2.plot(SNR_dB,RMSE_upper_bound,label="Upper Bound")
plt.legend(loc='upper right', fontsize=14)

# textstr = '0\% perturbations \n in surface time-delay'
# props = dict(boxstyle='round', facecolor='white', alpha=0.8)
# place a text box in upper left in axes coords
# ax.text(0.65, 0.7, textstr, transform=ax.transAxes, fontsize=14,
#         verticalalignment='top', bbox=props)

ax2.grid()

ax2.set_xlabel('SNR [dB]', fontsize=14)
ax2.set_ylabel(r'$\sqrt{\mathbb{E}[\varepsilon^2]}$ [m]', fontsize=14)
ax2.set_title(r'Location RMSE vs. SNR, $L=4$ sensors, $T=100$ samples', fontsize=14)
plt.xticks(fontsize=14)
plt.yticks(fontsize=14)
fig2
fig2.savefig('DLOC_RMSE_vs_SNR_bellhop_env_single_realization_ID1_mm2_batch_G_with_bound.png')