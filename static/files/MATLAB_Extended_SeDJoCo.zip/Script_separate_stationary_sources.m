% Script - Demonstration of semi-blind separation of stationary sources
%          using the extended SeDJoCo solution by Newton's method
%
% Other m-files required: Solve_Extended_SeDJoCo.m
%                         
%
% Subfunctions: generate_FIR_filters, gen_spectral_matrices_4_extsedjoco,
%               gen_matrices_4_extsedjoco, Solve_M_independent_SeDJoCo
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% See also: readmeExtendedSeDJoCo.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------

clear;
clc;

%%
K = 3; % Number of sources
M = 3; % Number of datasets
T = (M*K^2)*100; % Sample size, for this example we take 100 vector samples per unknown
L = 10; % Number of FIR coefficients
eta = 1; % Relative energy of cross-correlations, see eq. (62) in [1]
tolerance = 1e-15; % Tolerance constant for definition of convergence
max_iter_SeDJoCo = 1e3; % Maximum number of iterations allowed for SeDJoCo
max_iter_Extended_SeDJoCo = 1e2; % Maximum number of iterations allowed for Extended SeDJoCo

%%
% Generation of the FIR filters
H = generate_FIR_filters(K,M,L,eta);
% Generation of spectra & cross-spectra (diagonal) matrices of the sources
[Cf,Pf,Pcf] = generate_spectral_matrices_4_extsedjoco(K,M,T,L,H);


%%

% Generate sources, mixuters and target matrices
[Q,Qc,A,X] = generate_matrices_4_extsedjoco(K,M,T,L,H,Pf,Pcf);
% Solve M independent SeDJoCo problem to obtain a "good" initial solution
B_initial = Solve_M_independent_SeDJoCo(Qc,tolerance,max_iter_SeDJoCo);
% Solve the Extended SeDJoCo problem
[B_est,iteration_counter,cost_results] = Solve_Extended_SeDJoCo_Newton(B_initial,Q,max_iter_Extended_SeDJoCo,tolerance);
% Compute global demixing-mixing matrices
G_E_SeDJoCo = zeros(K,K,M);
for m=1:M
    G_E_SeDJoCo(:,:,m) = B_est(:,:,m)*A(:,:,m);
    disp(['Global demixing-mixing matrix of dataset ',num2str(m),':'])
    G_E_SeDJoCo(:,:,m)
end

%------------- END OF CODE --------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------ LOCAL FUNCTIONS -----------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ H ] = generate_FIR_filters(K,M,L,eta)
% generate_FIR_filters - Generate FIR filters for temporal "coloring" of the sources
%
% Syntax:  [ H ] = generate_FIR_filters(K,M,L,eta)
%
% Inputs:
%    K              - Number of sources
%    M              - Number of datasets
%    L              - Number of FIR coefficients
%    eta            - Relative energy of cross-correlations, see eq. (62) in [1]
%
% Outputs:
%    H              - The FIR filters: H(k,:,m1,m2) are the L taps of the 
%                     filter applied to the m2-th white driving-noise in 
%                     order to generate a component of the m1-th source signal,
%                     where k is the source index (and m1, m2 are the group indices)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------

H=randn(K,L,M,M);
%avoid roots which are too close to the unit circle and might cause
%problems with the inverses
%in addition, normalize the "self" filters to unit energy, and the
%cross-filters to rho energy
if L~=1
    for k=1:K
        for m1=1:M
            for m2=1:M
                h=H(k,:,m2,m1);
                roo=roots(h);
                absr=abs(roo);
                badr=find(absr<1.1 & absr>0.9);
                roo(badr)=roo(badr)./absr(badr)*0.7;
                h=poly(roo);
                eh=h*h';
                h=h/sqrt(eh);
                if m1~=m2
                    h=h*sqrt(eta);
                end
                H(k,:,m2,m1)=h;
            end
        end
    end
end

end

%------------- END OF CODE --------------

function [ Cf,Pf,Pcf ] = generate_spectral_matrices_4_extsedjoco(K,M,T,L,H)
% generate_spectral_matrices_4_extsedjoco - Generate spectra & cross-spectra 
%                                           (diagonal) matrices of the sources
%
% Syntax:  [ Cf,Pf,Pcf ] = generate_spectral_matrices_4_extsedjoco(K,M,T,L,H)
%
% Inputs:
%    K              - Number of sources
%    M              - Number of datasets
%    T              - Sample size
%    L              - Number of FIR coefficients
%    H              - FIR filters
%
% Outputs:
%    Cf(K,T,M,M)    - DFTs of the "individual" covariance matrices
%    Pf(K,T,M,M)    - Blocks of inverse of Cf
%    Pcf(K,TM)      - Blocks of inverse of Cf, while ignoring cross-correlations
%                     for the initial ICA ML guess
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------

% Compute the frequency domain FIRs
Hf=zeros(K,T,M,M);
zTmL=zeros(1,T-L);
for k=1:K
    for m1=1:M
        for m2=1:M
            h=H(k,:,m2,m1);
            hf=fft([h zTmL]);
            Hf(k,:,m2,m1)=hf;
        end
    end
end
% Calculate the "individual" covariance matrices:
% In the frequency domain they become diagonal,
% so only the diagonals need to be stored
Cf=zeros(K,T,M,M);
for k=1:K
    for m1=1:M
        for m2=1:M
            c0=zeros(1,T);
            for m=1:M
                h_m1m=Hf(k,:,m1,m);
                h_m2m=Hf(k,:,m2,m);
                c0=c0+h_m2m.*conj(h_m1m);
            end
            Cf(k,:,m1,m2)=c0;
        end
    end
end
% Construct the "large" covariance matrices and their inverses,
% and break the large inverse into its blocks. Since this is all done in 
% the Fourier domain with diagonal matrices, it is done individually in 
% each frequency
Pf=zeros(K,T,M,M);
Pcf=zeros(K,T,M);   %just the "central" ones, for the initial ICA ML guess
for k=1:K
    for t=1:T
        Cft=squeeze(Cf(k,t,:,:));
        Pf(k,t,:,:)=inv(Cft);
        Pcf(k,t,:)=1./diag(Cft);
    end
end

end

%------------- END OF CODE --------------

function [ Q,Qc,A,X ] = generate_matrices_4_extsedjoco(K,M,T,L,H,Pf,Pcf)
% generate_matrices_4_extsedjoco - Generate source, mixing matrices,
%                                  mixtures, and the associated target-matrices
%
% Syntax:  [ Q,Qc,A,X ] = generate_matrices_4_extsedjoco(K,M,T,L,H,Pf,Pcf)
%
% Inputs:
%    K              - Number of sources
%    M              - Number of datasets
%    T              - Sample size
%    L              - Number of FIR coefficients
%    H              - FIR filters
%    Pf             - Blocks of inverse of Cf
%    Pcf            - Blocks of inverse of Cf, while ignoring cross-correlations
%
% Outputs:
%    Q              - Target-matrices for the associated extended SeDJoCo problem
%    Qc             - Target-matrices for the associated M indepedent SeDJoCo problems
%    A              - The M mixing matrices
%    X              - The M mixtures
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------

% Normalizing coefficients
cfft=1/sqrt(T);
cifft=sqrt(T);

% True mixing matrices
A=randn(K,K,M);

% Generate the sources, see eq. (61) in [1]
W=randn(K,T,M);   %White noises
S=zeros(K,T,M);
Hf=zeros(K,T,M,M);
zTmL=zeros(1,T-L);
for k=1:K
    for m1=1:M
        w=squeeze(W(k,:,m1));
        wf=fft(w)*cfft;
        for m2=1:M
            h=H(k,:,m2,m1);
            hf=fft([h zTmL]);
            Hf(k,:,m2,m1)=hf;
            sf=ifft(hf.*wf)*cifft;
            S(k,:,m2)=S(k,:,m2)+sf;
        end
    end
end

% Create the mixtures
X=zeros(K,T,M);
for m=1:M
    X(:,:,m)=A(:,:,m)*S(:,:,m);
end

% Compute their DFTs
Xf=zeros(K,T,M);
for k=1:K
    for m=1:M
        Xf(k,:,m)=fft(X(k,:,m))*cfft;
    end
end

% Create the target-matrices
Q=zeros(K,K,K,M,M);
for k=1:K
    for m1=1:M
        for m2=1:M
            PF=repmat(Pf(k,:,m1,m2),K,1);
            Q(:,:,k,m1,m2)=real((Xf(:,:,m1).*PF)*Xf(:,:,m2)');
        end
    end
end
Q=Q/T;

% Create the "central" target-matrices, for finding the 
% SeDJoCo solution as an initial guess
Qc=zeros(K,K,K,M);
for k=1:K
    for m=1:M
        PcF=repmat(Pcf(k,:,m),K,1);
        Qc(:,:,k,m)=real((Xf(:,:,m).*PcF)*Xf(:,:,m)');
    end
end
Qc=Qc/T;

end

%------------- END OF CODE --------------

function [ B_est,cost ] = Solve_M_independent_SeDJoCo(Q,tolerance,max_iter,B_initial_input)
% Solve_M_independent_SeDJoCo - Solve M individual SeDJoCo problems
%
% Syntax:  [ B,cost ] = Solve_M_independent_SeDJoCo(Q,tolerance,max_iter,B_initial_input)
%
% Inputs:
%    Q                - Target-matrices for the associated M SeDJoCo problem
%    tolerance        - Tolerance constant for definition of convergence
%    max_iter         - Number of maximum iterations allowed
%    B_initial_input  - Initial solution (not necessary for execution, but helpful)
%
% Outputs:
%
%    B_est          - Estimated separation matrices (M solutions of M SeDJoCo problmes)
%    cost           - Value of cost funxtion evaluated for convergence
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------

K = size(Q,1);
M = size(Q,4);
if nargin~=4
    B_initial = zeros(K,K,M);
    for m=1:M
        B_initial(:,:,m) = eye(K);
    end
else
    B_initial = B_initial_input;
end

cost = -inf;
B_est = zeros(K,K,M);
for m=1:M
    Q_m = squeeze(Q(:,:,:,m));
    [ B_est(:,:,m),~,cost_m ] = Solve_Extended_SeDJoCo_Newton(B_initial(:,:,m),Q_m,max_iter,tolerance);
    cost = max([cost cost_m]);
end

end

%------------- END OF CODE --------------