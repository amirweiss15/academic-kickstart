function [ B_est, iteration_counter, cost_results ] = Solve_Extended_SeDJoCo_IR(B_initial,Q,max_iter,tolerance)
% Solve_Extended_SeDJoCo_IR - Solve extedned SeDJoCo using IR
% method
%
% Syntax:  [ B_est,iteration_counter, log_cost_results ] = Solve_Extended_SeDJoCo_IR(B_initial,Q,max_iter)
%
% Inputs:
%    B_initial          - M KxK matrices, an initial solution to extended SeDJoCo
%    Q                  - The associated target matrices (K*M^2 KxK matrices)
%    max_iter           - Number of maximum iterations alowed for the iterative procedure
%    tolerance          - Tolerance for convergence
%
% Outputs:
%    B_est              - Solution of the extended SeDJoCo problem
%    iteration_counter  - Number of iteration to convergence
%    cost_results       - the value of the cost function, eq. (56) in [1]
%
% Other m-files required: none
% Subfunctions: compute_Extended_cost_function
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% See also: readmeExtendedSeDJoCo.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------
M = size(B_initial,3);
K = size(B_initial,2);
cost_results = zeros(1,max_iter);
iteration_counter = 0;
B_est = B_initial;
cost = compute_Extended_cost_function(B_est,Q);
while (iteration_counter<max_iter && cost>tolerance)
    for m=1:M
        for k=1:K
            B_transformed_m_k = compute_projection_matrix(squeeze(B_est(:,:,:)),squeeze(Q(:,:,:,:,:)),m);
            if k==1
                B_proj_m_k = B_transformed_m_k(2:K,:);
            else
                if k==K
                    B_proj_m_k = B_transformed_m_k(1:K-1,:);
                else
                    B_proj_m_k = B_transformed_m_k([1:k-1 k+1:K],:);
                end
            end
            b_m_k = B_est(k,:,m)';
            b_m_k = b_m_k-B_proj_m_k'*((B_proj_m_k*B_proj_m_k')\(B_proj_m_k*b_m_k));
            B_est(k,:,m) = (b_m_k')/sqrt(abs(B_transformed_m_k(k,:)*b_m_k));
        end
    end
    iteration_counter = iteration_counter + 1;
    cost_results(iteration_counter) = compute_Extended_cost_function(B_est,Q);
    cost = cost_results(iteration_counter);
end

end
%------------- END OF CODE --------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------ LOCAL FUNCTIONS -----------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ cost_function ] = compute_Extended_cost_function(B_tensor,Q_tensor)
% compute_Extended_cost_function - Computes the cost function of an extended SeDJoCo problem
%
% Syntax:  [ cost_function ] = compute_Extended_cost_function(B_tensor,Q_tensor)
%
% Inputs:
%    B_tensor              - Current value of the B matrices
%    Q_tensor              - The tensor of target matrices
%
% Outputs:
%    cost_function         - The values of the cost function, eq. (56) in [1]
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------
M = size(B_tensor,3);
K = size(B_tensor,1);
summation_matrices = zeros(K,K,M);
cost_matrices = zeros(K,K,M);
I = eye(K);
E_tensor = zeros(K,K,K);
for k=1:K
    E_tensor(k,k,k) = 1;
end
for l=1:M
    for k=1:K
        for m=1:M
            summation_matrices(:,:,l) = summation_matrices(:,:,l) + E_tensor(:,:,k)*B_tensor(:,:,m)*Q_tensor(:,:,k,m,l)*(B_tensor(:,:,l)');
        end
    end
    cost_matrices(:,:,l) = summation_matrices(:,:,l) - I;
end
cost_function = sum(cost_matrices(:).^2);
end
%------------- END OF CODE --------------

function [ B_transformed ] = compute_projection_matrix( B_tensor,Q_tensor,m )
% compute_projection_matrix - Computes the projection matrix as in eq. (44) in [1]
%
% Syntax:  [ B_updated ] = compute_projection_matrix( B_tensor,Q_tensor,m )
%
% Inputs:
%    B_tensor              - Current value of the B matrices
%    Q_tensor              - The tensor of target matrices
%    m                     - index of the current m-th dataset
%
% Outputs:
%    B_transformed         - The transformed B matrix as in eq. (44) in [1]
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------
M = size(Q_tensor,4);
K = size(B_tensor,1);
B_transformed = zeros(K,K);
for k_row=1:K
    b_k_row_transformed = 0;
    for l=1:M
        b_k_row_transformed = b_k_row_transformed+...
            Q_tensor(:,:,k_row,m,l)*(B_tensor(k_row,:,l)');
    end
    B_transformed(k_row,:) = b_k_row_transformed';
end
end
%------------- END OF CODE --------------