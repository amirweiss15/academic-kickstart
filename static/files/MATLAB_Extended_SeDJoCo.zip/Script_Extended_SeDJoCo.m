% Script - Demonstration of the extended SeDJoCo solution by two iterative
%          algorithms: Newton's method, and IR
%
% Other m-files required: Solve_Extended_SeDJoCo.m
% Subfunctions: gen_matrices_4_generic_extsedjoco
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% See also: readmeExtendedSeDJoCo.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------

clear;
clc;

% Set values of related parameters

M = 4; % number of detasets
K = 5; % number of sources (and sensors)
num_of_max_iterations = 1e5;
tolerance = 1e-15;

% Generate a naive initial solution
B_initial = zeros(K,K,M);
for m=1:M
    B_initial(:,:,m) = eye(K);
end

% Generate a set of target matrices
Q = gen_matrices_4_generic_extsedjoco(K,M);

% Solve Extended SeDJoCo

% Newton's method
tic;
[ B_est_Newton, num_of_iterations_Newton, cost_Newton ] =...
    Solve_Extended_SeDJoCo_Newton(B_initial,Q,num_of_max_iterations,tolerance);
Newton_run_time = toc;

% IR
tic;
[ B_est_IR, num_of_iterations_IR, cost_IR ] =...
    Solve_Extended_SeDJoCo_IR(B_initial,Q,num_of_max_iterations,tolerance);
IR_run_time = toc;

disp('*******************************************************************');
disp('Convergence Results');
disp('-------------------');
disp('Newton''s method:');
disp(['Cost function value: ',num2str(cost_Newton(num_of_iterations_Newton)),', Runtime: ', num2str(Newton_run_time),' [sec]']);
disp('IR:');
disp(['Cost function value: ',num2str(cost_IR(num_of_iterations_IR)),', Runtime: ', num2str(IR_run_time),' [sec]']);
disp('*******************************************************************');

%------------- END OF CODE --------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------ LOCAL FUNCTIONS -----------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ Q ] = gen_matrices_4_generic_extsedjoco(K,M)
% gen_matrices_4_generic_extsedjoco - Generation of a target-matrices for a
%                                     generic extended SeDJoCo problem
%
% Syntax:  [ Q ] = gen_matrices_4_generic_extsedjoco(K,M)
%
% Inputs:
%    K                     - Dimension of the suqare matrices in the set
%    M                     - The number of the "datasets", giving rise to a total of M^2 target matrices
%
% Outputs:
%    Q                      - A set of K*M^2 KxK target matrices
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------
Q = zeros(K,K,K,M,M);
for k=1:K
    U_k = randn(M*K,M*K);
    Omega_k = U_k*U_k';
    for m1=1:M
        for m2=1:M
            Q(:,:,k,m1,m2) = Omega_k(1+(m1-1)*K:m1*K,1+(m2-1)*K:m2*K);
        end
    end
end
%------------- END OF CODE --------------

end

