function [ B_est,iteration_counter, cost_results ] = Solve_Extended_SeDJoCo_Newton(B_initial,Q,max_iter,tolerance)
% Solve_Extended_SeDJoCo_Newton - Solve extedned SeDJoCo using Newton's
% method
%
% Syntax:  [ B_est,iteration_counter, log_cost_results ] = Solve_Extended_SeDJoCo_Newton(B_initial,Q,max_iter)
%
% Inputs:
%    B_initial          - M KxK matrices, an initial solution to extended SeDJoCo
%    Q                  - The associated target matrices (K*M^2 KxK matrices)
%    max_iter           - Number of maximum iterations alowed for the iterative procedure
%    tolerance          - tolerance for convergence
%
% Outputs:
%    B_est              - Solution of the extended SeDJoCo problem
%    iteration_counter  - Number of iteration to convergence
%    log_cost_results   - log of the cost function, eq. (56) in [1]
%
% Other m-files required: none
% Subfunctions: compute_Extended_cost_function, compute_Grad, compute_Hessian
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% See also: readmeExtendedSeDJoCo.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------
M = size(B_initial,3);
K = size(B_initial,2);
cost_results = zeros(1,max_iter);
iteration_counter = 1;
B_est = B_initial;
cost = compute_Extended_cost_function(B_est,Q);
while (iteration_counter<max_iter && cost>tolerance)
    G = compute_Grad(B_est,Q);
    g = G(:);
    H = compute_Hessian(B_est,Q);
    delta = -H\g;
    Delta = reshape(delta,K,K,M);
    B_est = B_est + Delta;
    iteration_counter = iteration_counter + 1;
    cost_results(iteration_counter) = compute_Extended_cost_function(B_est,Q);
    cost = cost_results(iteration_counter);
end

end
%------------- END OF CODE --------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------ LOCAL FUNCTIONS -----------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ cost_function ] = compute_Extended_cost_function(B_tensor,Q_tensor)
% compute_Extended_cost_function - Computes the cost function of an extended SeDJoCo problem
%
% Syntax:  [ cost_function ] = compute_Extended_cost_function(B_tensor,Q_tensor)
%
% Inputs:
%    B_tensor              - Current value of the B matrices
%    Q_tensor              - The tensor of target matrices
%
% Outputs:
%    cost_function         - The values of the cost function, eq. (56) in [1]
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------
M = size(B_tensor,3);
K = size(B_tensor,1);
summation_matrices = zeros(K,K,M);
cost_matrices = zeros(K,K,M);
I = eye(K);
E_tensor = zeros(K,K,K);
for k=1:K
    E_tensor(k,k,k) = 1;
end
for l=1:M
    for k=1:K
        for m=1:M
            summation_matrices(:,:,l) = summation_matrices(:,:,l) + E_tensor(:,:,k)*B_tensor(:,:,m)*Q_tensor(:,:,k,m,l)*(B_tensor(:,:,l)');
        end
    end
    cost_matrices(:,:,l) = summation_matrices(:,:,l) - I;
end
cost_function = sum(cost_matrices(:).^2);
end
%------------- END OF CODE --------------

function [ H ] = compute_Hessian(B_tensor,Q_tensor)
% compute_Hessian - Computation of the Hessian matrix
%
% Syntax:  [ H ] = compute_Hessian(B_tensor,Q_tensor)
%
% Inputs:
%    B_tensor              - Current value of the B matrices
%    Q_tensor              - The tensor of target matrices
%
% Outputs:
%    H                     - The Hessian of the log-likelihood, eq. (52) in [1]
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M = size(B_tensor,3);
K = size(B_tensor,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E_kk = zeros(K,K,K);
for k=1:K
    E_kk(k,k,k) = 1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
I_K = eye(K);
E_tilda_K = zeros(K^2,K^2);
E_K = zeros(K^2,K^2);
for k1=1:K
    for k2=1:K
        E_K( (1+(k1-1)*K):(k1*K), (1+(k2-1)*K):(k2*K) ) = I_K(:,k1)*I_K(k2,:);
        E_tilda_K( (1+(k1-1)*K):(k1*K), (1+(k2-1)*K):(k2*K) ) = I_K(:,k2)*I_K(k1,:);
    end
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
H_premuted = zeros(M*K^2,M*K^2);
for i=1:M
    for j=1:M
        summation = 0;
        for k=1:K
            summation = summation + kron(I_K,E_kk(:,:,k))*E_K*kron(I_K,Q_tensor(:,:,k,i,j));
        end
        if i==j
            H_i_j = -kron(I_K,inv(B_tensor(:,:,j))')*E_tilda_K*kron(I_K,inv(B_tensor(:,:,j))')-summation;
        else
            H_i_j = -summation;
        end
        H_premuted( (1+(j-1)*K^2):(j*K^2), (1+(i-1)*K^2):(i*K^2) ) = H_i_j;
    end
end

% fix permutation
H = zeros(M*K^2,M*K^2);
for i=1:M
    for j=1:M
        for m=1:K
            for n=1:K
                for p=1:K
                    for q=1:K
                        H( (i-1)*K^2+(q-1)*K+p,(j-1)*K^2+(n-1)*K+m ) = H_premuted( (i-1)*K^2+(m-1)*K+p,(j-1)*K^2+(n-1)*K+q );
                    end
                end
            end
        end
    end
end
                    

end
%------------- END OF CODE --------------

function [ G ] = compute_Grad(B_tensor,Q_tensor)
% compute_Grad - Computation of the gradient matrix
%
% Syntax:  [ G ] = compute_Grad(B_tensor,Q_tensor)
%
% Inputs:
%    B_tensor              - Current value of the B matrices
%    Q_tensor              - The tensor of target matrices
%
% Outputs:
%    G                     - The gradient of the log-likelihood, eq. (45) in [1]
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Sequentially Drilled� Joint Congruence Transformation and
%			  its Application in Gaussian Independent Vector Analysis",
%		      Weiss, A., Yeredor, A., Cheema, S. A. and Haardt, M.,
%			  IEEE Trans. Signal Process., vol. 65, no. 23, pp. 1-13, Dec. 2017.
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Sep. 2020; Last revision: 06-Sep-2020
%------------- BEGIN CODE --------------
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
M = size(B_tensor,3);
K = size(B_tensor,2);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
E_kk = zeros(K,K,K);
for k=1:K
    E_kk(k,k,k) = 1;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
G = [];
for l=1:M
    summation = 0;
    for k=1:K
        for m=1:M
            summation = summation + E_kk(:,:,k)*B_tensor(:,:,m)*Q_tensor(:,:,k,m,l);
        end
    end
    G_l = inv(B_tensor(:,:,l))'-summation;
    G = [G G_l];
end

end
%------------- END OF CODE --------------