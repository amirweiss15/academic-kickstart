function [FIM_signal,FIM_noise] = compute_FIM_3ray_model(p,S,B,sigma_v_sqrd_vec,p_array,h,c,w)
% compute_FIM_3ray_model - Compute Fisher information matrix (FIM) for the three-ray model
%
% Syntax:  [FIM_signal,FIM_noise] = compute_FIM_3ray_model(p,S,B,sigma_v_sqrd_vec,p_array,h,c,w)
%
% Inputs:
%    p                - Vector of the source hypothesized position (a 3 x 1 vector)
%    S                - DFT vector of the waveform emitted from the source (a 1 x T complex-valued vector)
%                       Note: We assume |s[k]|=constant w.r.t. the index k
%    B                - 3 x L complex valued matrix of attenuation coefficients from 3 reflections
%    sigma_v_sqrd_vec - L variances of noise processes
%    p_array          - A Matrix whose columns are the position vectors of the receivers (a 3 x L real-valued matrix) 
%    h                - The bottom depth in the area of interest
%    w                - Vector of the corresponding N DFT frequencies (a 1 x N real-valued vector)
%    c                - speed of sound in the medium (a positive real-valued scalar)
%
% Output:
%    FIM_signal       - The signal-related block of the FIM 
%    FIM_noise        - The noise-related block of the FIM
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Based on the paper:
%			 "A Semi-Blind Method for Localization of Underwater Acoustic Sources", Amir Weiss, Toros Arikan,
%            Hari Vishnu, Grant B. Deane, Andrew C. Singer, and Gregory W. Wornell,
%			 submitted of IEEE Trans. on Signal Processing , October 2021.
%
% See also: readmeSBL.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% October 1 2021
%
% *********************************************************************
% List of the *unknowns*:
% 1. p: position of the emitter in 3D space
% 2. S: T-length DFT of the baseband signal emitter from the source
% *Throughout, we assume |s[k]|=R_s, constant w.r.t. the index k
% 3. B: 3 x L matrix of attenuation coefficients from 3 reflections
% (LOS, surface NLOS, bottom NLOS) from all L sensors
% 4. sigma_v_sqrd_vec: L variances of noise processes
%
% List of *known* parameters: (necessary for computing the FIM)
% 1. p_array: 3 x L matrix of 3D positions of the L sensors
% 2. h: ocean depth at the working environment
% 3. c: speed of sound (assumed to be constant)
% 4. w: vector of DFT frequencies
% *********************************************************************

T = length(S);
L = size(B,2);
x0 = p(1);
y0 = p(2);
z0 = p(3);
x_receiver = p_array(1,:)';
y_receiver = p_array(2,:)';
z_receiver = p_array(3,:)';
w = w(:);
S = S(:);

theta_sig_dim = 3 + T + 2*3*L; % 2 x 3L: real and imaginary parts
theta_noise_dim = L;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ALL CROSS-BLOCKS OF NOISE AND SIGNAL-RELATED ARE ALL-ZEROS MATRICES
FIM_signal = zeros(theta_sig_dim,theta_sig_dim);
FIM_noise = T*eye(theta_noise_dim);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Compute Necessary quantities

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute the matrix of complex exponential due to the channel delays and
% the channel response of each receiver
D = zeros(T,3,L);
H = zeros(T,L);
tau = zeros(L,3);
R = zeros(3,L);
for l_ind=1:L
    
    b = B(:,l_ind);

    R(1,l_ind) = sqrt( (x0-x_receiver(l_ind)).^2 + (y0-y_receiver(l_ind)).^2 + (z0-z_receiver(l_ind)).^2 );
    tau(l_ind,1) = R(1,l_ind)/c;
    R(2,l_ind) = sqrt ( R(1,l_ind)^2 + (z0 + z_receiver(l_ind))^2 );
    tau(l_ind,2) = R(2,l_ind)/c;
    R(3,l_ind) = sqrt ( R(1,l_ind)^2 + (2*h - z0 - z_receiver(l_ind))^2 );
    tau(l_ind,3) = R(3,l_ind)/c;
    
    D(:,:,l_ind) = exp(1i*w*tau(l_ind,:));
    
    H(:,l_ind) = conj( D(:,:,l_ind) )*b;
     
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Inverse of covariance matrix
% D_sigma_v_inverse = diag( kron((1./sigma_v_sqrd_vec(:)),ones(T,1)) );
D_sigma_v_inverse_vec = kron((1./sigma_v_sqrd_vec(:)),ones(T,1));
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Derivative of the mean vector w.r.t. the signal's phase
dhd_phi_s = zeros(T*L,T);
I_T = eye(T);
for k_ind=1:T
    H_k = transp(H(k_ind,:));
    dhd_phi_s(:,k_ind) = 1i*S(k_ind)*( kron( H_k , I_T(:,k_ind) ) );
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Derivative of the mean vector w.r.t. the real part of the attenuation
% coefficients, B

% Real part of B 
dhdb_real = zeros(T*L,3,L);
I_L = eye(L);
I_3 = eye(3);
for l_ind=1:L
    for r_ind=1:3 % index of LOS/NLOS component
        dhdb_real(:,r_ind,l_ind) = kron( I_L(:,l_ind) , S.*( conj( D(:,:,l_ind) )*I_3(:,r_ind) ) );
    end
end

% Imaginary part of B 
dhdb_imag = 1i*dhdb_real;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Derivative of the mean vector w.r.t. the unknow position vector, p

% Step 1: compute derivative of delyas w.r.t. the to position coorinates
dtaudp = zeros(3,3,L); % p dimension X LOS/NLOS dimension X sensor dimension
for l_ind=1:L
    %%%%%%%%%%%%%%%%%%%%
    % x coordinate
    p_ind = 1;
    % LOS
    r_ind = 1;
    dtaudp(p_ind,r_ind,l_ind) = ( x0-x_receiver(l_ind) )/( c*R(r_ind,l_ind) );
    % NLOS surface reflection
    r_ind = 2;
    dtaudp(p_ind,r_ind,l_ind) = ( x0-x_receiver(l_ind) )/( c*R(r_ind,l_ind) );
    % NLOS bottom reflection
    r_ind = 3;
    dtaudp(p_ind,r_ind,l_ind) = ( x0-x_receiver(l_ind) )/( c*R(r_ind,l_ind) );
    
    %%%%%%%%%%%%%%%%%%%%
    % y coordinate
    p_ind = 2;
    % LOS
    r_ind = 1;
    dtaudp(p_ind,r_ind,l_ind) = ( y0-y_receiver(l_ind) )/( c*R(r_ind,l_ind) );
    % NLOS surface reflection
    r_ind = 2;
    dtaudp(p_ind,r_ind,l_ind) = ( y0-y_receiver(l_ind) )/( c*R(r_ind,l_ind) );
    % NLOS bottom reflection
    r_ind = 3;
    dtaudp(p_ind,r_ind,l_ind) = ( y0-y_receiver(l_ind) )/( c*R(r_ind,l_ind) );
    
    %%%%%%%%%%%%%%%%%%%%
    % z coordinate
    p_ind = 3;
    % LOS
    r_ind = 1;
    dtaudp(p_ind,r_ind,l_ind) = ( z0-z_receiver(l_ind) )/( c*R(r_ind,l_ind) );
    % NLOS surface reflection
    r_ind = 2;
    dtaudp(p_ind,r_ind,l_ind) = ( 2*z0 )/( c*R(r_ind,l_ind) );
    % NLOS bottom reflection
    r_ind = 3;
    dtaudp(p_ind,r_ind,l_ind) = ( 2*(z0-h) )/( c*R(r_ind,l_ind) );
end

% Step 2: compute derivative of D(l) w.r.t. the to position coorinates
dDconjdp = zeros(T,3,L,3); % D dimensions X sensor dimension X LOS/NLOS dimension
for l_ind=1:L % loop over sensor index
    for p_ind=1:3 % loop over dimension: 1 <--> p_x, 2 <--> p_y, 3 <--> p_z
        dDconjdp(:,:,l_ind,p_ind) = -1i*repmat(w,1,3).*conj( D(:,:,l_ind) ).*repmat(dtaudp(p_ind,:,l_ind),T,1);
    end
end

% Step 3: compute derivative of the mean vector w.r.t. the unknow position vector, p
dhdp = zeros(T*L,3); % mean vector dimension X p dimension
for l_ind=1:L
    for p_ind=1:3
        dhdp(1+(l_ind-1)*T:T+(l_ind-1)*T,p_ind) = S.*( dDconjdp(:,:,l_ind,p_ind)*B(:,l_ind) );
    end
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Compute FIM matrix of signal and channel related parameters
% Block to compute:
% FIM(p,p): 3x3
% FIM(p,phi_S): 3xT
% FIM(p,real(vec(B))): 3x3L
% FIM(p,imag(vec(B))): 3x3L
% FIM(phi_S,phi_S): TxT
% FIM(phi_S,real(vec(B))): Tx3L
% FIM(phi_S,imag(vec(B))): Tx3L
% FIM(real(vec(B)),real(vec(B))): 3Lx3L
% FIM(real(vec(B)),imag(vec(B))): 3Lx3L
% FIM(imag(vec(B)),imag(vec(B))): 3Lx3L

% FIM(p,p): 3x3
FIM_p_p = zeros(3,3);
for p_ind1=1:3
    for p_ind2=1:3
       FIM_p_p(p_ind1,p_ind2) = 2*real(dhdp(:,p_ind1)'*(D_sigma_v_inverse_vec.*dhdp(:,p_ind2)));
    end
end
FIM_signal(1:3,1:3) = FIM_p_p;

% FIM(p,phi_S): 3xT
FIM_p_phi_S = zeros(3,T);
for p_ind=1:3
    for phi_S_ind=1:T
       FIM_p_phi_S(p_ind,phi_S_ind) = 2*real(dhdp(:,p_ind)'*(D_sigma_v_inverse_vec.*dhd_phi_s(:,phi_S_ind)));
    end
end
FIM_signal(1:3,3+1:3+T) = FIM_p_phi_S;
FIM_signal(3+1:3+T,1:3) = FIM_p_phi_S.';

% FIM(p,real(vec(B))): 3x3L
FIM_p_real_B = zeros(3,3*L);
for p_ind=1:3
    for l_ind=1:L
        for r_ind=1:3
            real_B_ind = (l_ind-1)*3 + r_ind;
            FIM_p_real_B(p_ind,real_B_ind) = 2*real(dhdp(:,p_ind)'*(D_sigma_v_inverse_vec.*dhdb_real(:,r_ind,l_ind)));
        end
    end
end
FIM_signal(1:3,3+T+1:3+T+3*L) = FIM_p_real_B;
FIM_signal(3+T+1:3+T+3*L,1:3) = FIM_p_real_B.';

% FIM(p,imag(vec(B))): 3x3L
FIM_p_imag_B = zeros(3,3*L);
for p_ind=1:3
    for l_ind=1:L
        for r_ind=1:3
            imag_B_ind = (l_ind-1)*3 + r_ind;
            FIM_p_imag_B(p_ind,imag_B_ind) = 2*real(dhdp(:,p_ind)'*(D_sigma_v_inverse_vec.*dhdb_imag(:,r_ind,l_ind)));
        end
    end
end
FIM_signal(1:3,3+T+3*L+1:3+T+2*3*L) = FIM_p_imag_B;
FIM_signal(3+T+3*L+1:3+T+2*3*L,1:3) = FIM_p_imag_B.';

% FIM(phi_S,phi_S): TxT
FIM_phi_S_phi_S = zeros(T,T);
for phi_S_ind1=1:T
    for phi_S_ind2=1:T
       FIM_phi_S_phi_S(phi_S_ind1,phi_S_ind2) = 2*real(dhd_phi_s(:,phi_S_ind1)'*(D_sigma_v_inverse_vec.*dhd_phi_s(:,phi_S_ind2)));
    end
end
FIM_signal(3+1:3+T,3+1:3+T) = FIM_phi_S_phi_S;

% FIM(phi_S,real(vec(B))): Tx3L
FIM_phi_S_real_B = zeros(T,3*L);
for phi_S_ind=1:T
    for l_ind=1:L
        for r_ind=1:3
            real_B_ind = (l_ind-1)*3 + r_ind;
            FIM_phi_S_real_B(phi_S_ind,real_B_ind) = 2*real(dhd_phi_s(:,phi_S_ind)'*(D_sigma_v_inverse_vec.*dhdb_real(:,r_ind,l_ind)));
        end
    end
end
FIM_signal(3+1:3+T,3+T+1:3+T+3*L) = FIM_phi_S_real_B;
FIM_signal(3+T+1:3+T+3*L,3+1:3+T) = FIM_phi_S_real_B.';

% FIM(phi_S,imag(vec(B))): Tx3L
FIM_phi_S_imag_B = zeros(T,3*L);
for phi_S_ind=1:T
    for l_ind=1:L
        for r_ind=1:3
            imag_B_ind = (l_ind-1)*3 + r_ind;
            FIM_phi_S_imag_B(phi_S_ind,imag_B_ind) = 2*real(dhd_phi_s(:,phi_S_ind)'*(D_sigma_v_inverse_vec.*dhdb_imag(:,r_ind,l_ind)));
        end
    end
end
FIM_signal(3+1:3+T,3+T+3*L+1:3+T+2*3*L) = FIM_phi_S_imag_B;
FIM_signal(3+T+3*L+1:3+T+2*3*L,3+1:3+T) = FIM_phi_S_imag_B.';

% FIM(real(vec(B)),real(vec(B))): 3Lx3L
FIM_real_B_real_B = zeros(3*L,3*L);
for l_ind1=1:L
    for r_ind1=1:3
        real_B_ind1 = (l_ind1-1)*3 + r_ind1;
        for l_ind2=1:L
            for r_ind2=1:3
                real_B_ind2 = (l_ind2-1)*3 + r_ind2;
                FIM_real_B_real_B(real_B_ind1,real_B_ind2) = 2*real(dhdb_real(:,r_ind1,l_ind1)'*(D_sigma_v_inverse_vec.*dhdb_real(:,r_ind2,l_ind2)));
            end
        end
    end
end
FIM_signal(3+T+1:3+T+3*L,3+T+1:3+T+3*L) = FIM_real_B_real_B;

% FIM(real(vec(B)),imag(vec(B))): 3Lx3L
FIM_real_B_imag_B = zeros(3*L,3*L);
for l_ind1=1:L
    for r_ind1=1:3
        real_B_ind1 = (l_ind1-1)*3 + r_ind1;
        for l_ind2=1:L
            for r_ind2=1:3
                imag_B_ind2 = (l_ind2-1)*3 + r_ind2;
                FIM_real_B_imag_B(real_B_ind1,imag_B_ind2) = 2*real(dhdb_real(:,r_ind1,l_ind1)'*(D_sigma_v_inverse_vec.*dhdb_imag(:,r_ind2,l_ind2)));
            end
        end
    end
end
FIM_signal(3+T+1:3+T+3*L,3+T+3*L+1:3+T+2*3*L) = FIM_real_B_imag_B;
FIM_signal(3+T+3*L+1:3+T+2*3*L,3+T+1:3+T+3*L) = FIM_real_B_imag_B.';

% FIM(imag(vec(B)),imag(vec(B))): 3Lx3L
FIM_imag_B_imag_B = zeros(3*L,3*L);
for l_ind1=1:L
    for r_ind1=1:3
        imag_B_ind1 = (l_ind1-1)*3 + r_ind1;
        for l_ind2=1:L
            for r_ind2=1:3
                imag_B_ind2 = (l_ind2-1)*3 + r_ind2;
                FIM_imag_B_imag_B(imag_B_ind1,imag_B_ind2) = 2*real(dhdb_imag(:,r_ind1,l_ind1)'*(D_sigma_v_inverse_vec.*dhdb_imag(:,r_ind2,l_ind2)));
            end
        end
    end
end
FIM_signal(3+T+3*L+1:3+T+2*3*L,3+T+3*L+1:3+T+2*3*L) = FIM_imag_B_imag_B;

FIM_signal(4,:) = [];
FIM_signal(:,4) = [];

end

