function [lambda_max_p_c] = compute_SBL_cost_function(p_array,x_bar,h,w,p,c)
% compute_SBL_cost_function - Compute the SBL cost function for a position vector p
%
% Syntax:  [lambda_max_p_c] = compute_SBL_cost_function(p_array,x_bar,h,w,p,c)
%
% Inputs:
%    p_array   - A Matrix whose columns are the position vectors of the receivers (a 3 x L real-valued matrix) 
%    x_bar     - The DFT of the signals of all the receivers (an L x T complex-valued matrix)
%    h         - The bottom depth in the area of interest
%    w         - Vector of the corresponding N DFT frequencies (a 1 x N real-valued vector)
%    p         - Vector of the source hypothesized position (a 3 x 1 vector)
%    c         - speed of sound in the medium (a positive real-valued scalar)
%
% Output:
%    lambda_max_p_c - The value of the SBL cost function (eq. (23) in the paper)
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Based on the paper:
%			 "A Semi-Blind Method for Localization of Underwater Acoustic Sources", Amir Weiss, Toros Arikan,
%            Hari Vishnu, Grant B. Deane, Andrew C. Singer, and Gregory W. Wornell,
%			 submitted of IEEE Trans. on Signal Processing , October 2021.
%
% See also: readmeSBL.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% October 1 2021
%------------- BEGIN CODE --------------

[T,L] = size(x_bar);

x_cand = p(1);
y_cand = p(2);
z_cand = p(3);

x_receiver = p_array(1,:)';
y_receiver = p_array(2,:)';
z_receiver = p_array(3,:)';

Gamma = zeros(T,3,L);
Q_block = [];

for l=1:L
    
    distance_source_reciver_cand = sqrt( (x_cand-x_receiver(l)).^2 + (y_cand-y_receiver(l)).^2 + (z_cand-z_receiver(l)).^2 );
    tau1_cand = (distance_source_reciver_cand)/c;
    
    horizontal_distance = sqrt( (x_cand-x_receiver(l)).^2 + (y_cand-y_receiver(l)).^2 );
    
    distance_surface_bounce_cand = sqrt ( horizontal_distance^2 + (z_cand + z_receiver(l))^2 );
    tau2_cand = distance_surface_bounce_cand/c;
    
    distance_bottom_bounce_cand = sqrt ( horizontal_distance^2 + (2*h - z_cand - z_receiver(l))^2 );
    tau3_cand = distance_bottom_bounce_cand/c;
    
    tau_cand = [tau1_cand ; tau2_cand ; tau3_cand];
    
    D_l = transp(exp(-1i*tau_cand*w));
    
    try % Make sure 
        L_l = chol(D_l'*D_l);
    catch
        L_l = chol(D_l'*D_l + (1e-10)*eye(3));
    end
    Gamma(:,:,l) = (conj(x_bar(:,l)).*D_l)/L_l;
    Q_block = [Q_block Gamma(:,:,l)];
    
end

lambda_max_p_c = max(real(eig(Q_block'*Q_block)));

end
%------------- END OF CODE --------------
