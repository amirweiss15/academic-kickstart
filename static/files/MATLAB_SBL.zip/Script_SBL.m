% Script - Demonstration of the SBL estimation MATALB package
%
% Other m-files required: compute_SBL_cost_function.m, compute_SBL_estimate.m
% Subfunctions: compute_SBL_estimate
% MAT-files required: none
%
% Based on the paper:
%			 "A Semi-Blind Method for Localization of Underwater Acoustic Sources", Amir Weiss, Toros Arikan,
%            Hari Vishnu, Grant B. Deane, Andrew C. Singer, and Gregory W. Wornell,
%			 submitted of IEEE Trans. on Signal Processing , October 2021.
%
% See also: readmeSBL.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% October 1 2021
%------------- BEGIN CODE --------------

clear;
clc;

L = 4; % number of arrays
fmax = 1*1e3; % maximum frequency
T = 100; % smaple size

fft_coef = 1/sqrt(T); % DFT normalization coefficient
ifft_coef = sqrt(T); % DFT normalization coefficient

x0 = 123+rand; % true x coordinate of source [m]
y0 = 234+rand; % true y coordinate of source [m]
z0 = 17+rand;  % true z coordinate of source [m]

p = [x0 ; y0 ; z0];
x_receiver = (1e3)*[0.15 ; 0.05 ; -0.05 ; -0.15]; % x coordinate of the sensors [m]
y_receiver = (1e3)*[-0.25 ; -0.25 ; -0.25 ; -0.25]; % y coordinate of the sensors [m]
z_receiver = [10 ; 15 ; 20 ; 25]; % z coordinate of the sensors [m]
p_array = [x_receiver' ; y_receiver' ; z_receiver'];

c = 1535; % speed of sound

k_bottom = 0.7 + 0.1*(2*rand-1); % bottom coefficient

w = (0:1:T-1)*2*pi*fmax/T; % vector of DFT frequencies

h = 70+rand; % depth of the area considered

% Synthesize a signal based on the three-ray model

S = (randn(1,T) + 1i*randn(1,T))./sqrt(2); % random complex-normal waveform

effective_noise_power = 1;

tau = zeros(3,L);
b_true = zeros(3,L);
D = zeros(3,T,L);
x_bar = zeros(T,L);
for l=1:L
    
    distance_source_reciver = sqrt( (x0-x_receiver(l)).^2 + (y0-y_receiver(l)).^2 + (z0-z_receiver(l)).^2 );
    tau1 = distance_source_reciver/c;
    
    horizontal_distance = sqrt( (x0-x_receiver(l)).^2 + (y0-y_receiver(l)).^2 );
    
    distance_surface_bounce = sqrt ( horizontal_distance^2 + (z0 + z_receiver(l))^2 );
    tau2 = distance_surface_bounce/c;
    
    distance_bottom_bounce = sqrt ( horizontal_distance^2 + (2*h - z0 - z_receiver(l))^2 );
    tau3 = distance_bottom_bounce/c;
    
    tau(:,l) = [tau1 ; tau2 ; tau3];
    
    D(:,:,l) = exp(-1i*tau(:,l)*w);
    
    b_true(1,l) = 1/distance_source_reciver;
    b_true(2,l) = -1/distance_surface_bounce;
    b_true(3,l) = k_bottom/distance_bottom_bounce;
    
    b = b_true(:,l);
    
    % Genrate noise
    V = sqrt(effective_noise_power*(norm(b)^2))*(randn(1,T) + 1i*randn(1,T))./sqrt(2);
    
    % Generate DFT of received signal
    x_bar(:,l) = S.*(b.'*D(:,:,l)) + V;
    
end

x_candidate = linspace(0,300,40);
y_candidate = linspace(0,500,40);
z_candidate = linspace(0,h,40);

% Compute the SBL estimate
[p_est_SBL] = compute_SBL_estimate(p_array,x_bar,h,w,x_candidate,y_candidate,z_candidate,c);

% Compute the Cramer-Rao lower bound
[FIM_signal,FIM_noise] = compute_FIM_3ray_model(p,S./abs(S),b_true,effective_noise_power*(norm(b)^2)*ones(L,1),p_array,h,c,w);
CRLB_signal = inv(FIM_signal);
CRLB_position = diag(CRLB_signal(1:3,1:3));

% Note that the CRLB is computed for a spectrally-flat signal, whereas the
% algorithm is applied here to a non-spectrally-flat. To evaluate *only*
% the accuracy of the CRLB, modify the signal waveform S such that it will
% have a constant magnitude across all DFT components.

disp('************************************************************')
disp(['True x position:',num2str(p(1)),' |  Estimated x position:',num2str(p_est_SBL(1))])
disp(['True y position:',num2str(p(2)),' |  Estimated y position:',num2str(p_est_SBL(2))])
disp(['True z position:',num2str(p(3)),' |  Estimated z position:',num2str(p_est_SBL(3))])
disp('************************************************************')
disp(['CLRB (for spectrally flat waveform) on RMSE x position:',num2str(sqrt(CRLB_position(1)))])
disp(['CLRB (for spectrally flat waveform) on RMSE y position:',num2str(sqrt(CRLB_position(2)))])
disp(['CLRB (for spectrally flat waveform) on RMSE z position:',num2str(sqrt(CRLB_position(3)))])
%------------- END OF CODE --------------