function [p_est_SBL] = compute_SBL_estimate(p_array,x_bar,h,w,x_candidate,y_candidate,z_candidate,c)
% compute_SBL_estimate - Compute the SBL estimator (based on the three-ray model)
%
% Syntax:  [p_est_SBL] = compute_SBL_estimate(p_array,x_bar,h,w,x_candidate,y_candidate,z_candidate,c)
%
% Inputs:
%    p_array     - A Matrix whose columns are the position vectors of the receivers (a 3 x L real-valued matrix) 
%    x_bar       - The DFT of the signals of all the receivers (an L x T complex-valued matrix)
%    h           - The bottom depth in the area of interest
%    w           - Vector of the corresponding N DFT frequencies (a 1 x N real-valued vector)
%    x_candidate - Vector of grid point for x-axis 
%    y_candidate - Vector of grid point for y-axis
%    z_candidate - Vector of grid point for z-axis
%    c           - speed of sound in the medium (a positive real-valued scalar)
%
% Output:
%    p_est_SBL - The SBL estimator
%
% Other m-files required: compute_SBL_cost_function.m
% Subfunctions: compute_SBL_cost_function
% MAT-files required: none
%
% Based on the paper:
%			 "A Semi-Blind Method for Localization of Underwater Acoustic Sources", Amir Weiss, Toros Arikan,
%            Hari Vishnu, Grant B. Deane, Andrew C. Singer, and Gregory W. Wornell,
%			 submitted of IEEE Trans. on Signal Processing , October 2021.
%
% See also: readmeSBL.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% October 1 2021
%------------- BEGIN CODE --------------

dim_x_cand = length(x_candidate);
dim_y_cand = length(y_candidate);
dim_z_cand = length(z_candidate);

ind_vec = 1:(dim_x_cand*dim_y_cand*dim_z_cand);
length_ind_vec = dim_x_cand*dim_y_cand*dim_z_cand;

C_SBL = zeros(1,dim_x_cand*dim_y_cand*dim_z_cand);

parfor ind_parfor_loop=1:length_ind_vec
    [i_x,i_y,i_z] = ind2sub([dim_x_cand,dim_y_cand,dim_z_cand],ind_vec(ind_parfor_loop));
    x_cand = x_candidate(i_x);
    y_cand = y_candidate(i_y);
    z_cand = z_candidate(i_z);
    C_SBL(ind_parfor_loop) = compute_SBL_cost_function(p_array,x_bar,h,w,[x_cand; y_cand; z_cand],c);
end

[~,max_ind_SBL] = max(C_SBL);
[i_x_max_SBL,i_y_max_SBL,i_z_max_SBL] = ind2sub([dim_x_cand,dim_y_cand,dim_z_cand],max_ind_SBL);
p_est_SBL_grid = [x_candidate(i_x_max_SBL) ; y_candidate(i_y_max_SBL) ; z_candidate(i_z_max_SBL)];

ObjectiveFunction_SBL = @(p_cand) -compute_SBL_cost_function(p_array,x_bar,h,w,p_cand,c);
                                             
p_est_SBL = fminsearch(ObjectiveFunction_SBL,p_est_SBL_grid);

end
%------------- END OF CODE --------------
