function [ theta, theta_est, Q_factor, num_of_iter, s_n ] = ISEA( y_n )
% ISEA - Iterative Sign Estimation Algorithm (ISEA)
%
% Syntax:  [ theta, theta_est, Q_factor, num_of_iter, s_n ] = ISEA( y_n )
%
% Inputs:
%    y_n                - time-domain OFDM signal (N-dimensional vector)
%                         after absolute value distortion + additive noise
%
% Outputs:
%    theta              - detected symbols, namely "hard-estimates" (valid symbols on the constellation)
%    theta_est          - "soft-estimates" (not necessarily valid symbols on the constellation)
%    Q_factor           - scalar quality measure, the mean squared error
%                         between the hard-estimates and the soft-estimates
%    num_of_iter        - number of iterations executed until convergence
%    s_n                - corresponding estimated time-domain signal
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% References:
%	     [1] "Iterative Symbol Recovery for Power Efficient DC Biased Optical OFDM Systems",
%		      Weiss, A., Yeredor, A., Shtaif, M.,
%			  Journal of Lightwave Technology, vol. 34, no. 9, pp. 2331-2338, May 2016.
%
% See also: readmeISEA.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------

z_n_prev = ones(1,length(y_n));
num_of_iter = 0;
stop = 0;
while (~stop && num_of_iter<500)
    % 1 %
    num_of_iter = num_of_iter + 1;
    [theta, theta_est, Q_factor] = detect_symbols_from_indicators(y_n,z_n_prev);
    if ( num_of_iter~=1 )
        % 2 %
        if ( theta==theta_prev )
            % 3 %
            stop = 1;
            % 3 %
        end
        % 2 %
    end
    s_n = compute_s_n_from_symbols(theta);
    z_n = detect_indicators(s_n);
    z_n_prev = z_n;
    theta_prev = theta;
    % 1 %
end

end
%------------- END OF CODE --------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------ LOCAL FUNCTIONS -----------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ theta, theta_est, Q_factor ] = detect_symbols_from_indicators( y_n,z_n )
% detect_symbols_from_indicators - Detect the symblos, a_k, from measurements, y[n], and indicators, z[n].                                 
% Indicators defined by: (real & imaginary parts separately)
%         -
%        | 1    x[n]  > -M
%   z[n]=|
%        | 2    x[n]  <  -M
%         -
%
% Syntax:  [ theta, theta_est, Q_factor ] = detect_symbols_from_indicators( y_n,z_n )
%
% Inputs:
%    y_n                       - samples of the noisy absolute valued OFDM signal
%    z_n                       - indicator series for signs
%
% Outputs:
%    theta              - detected symbols, namely "hard-estimates" (valid symbols on the constellation)
%    theta_est          - "soft-estimates" (not necessarily valid symbols on the constellation)
%    Q_factor           - scalar quality measure, the mean squared error
%                         between the hard-estimates and the soft-estimates
%
% Other m-files required: detect_symbols_from_s_n.m
% Subfunctions: detect_symbols_from_s_n
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------

global M;

s_n_est = zeros(1,length(y_n));

% Set indices by indicators
index1 = find(z_n==1);
index2 = find(z_n==2);

% Set values by indicators
if (~isempty(index1))
    s_n_est(index1) = y_n(index1)-M;
end
if (~isempty(index2))
    s_n_est(index2) = -(y_n(index2)+M);
end

% Detect the symbols
[theta, theta_est, Q_factor] = detect_symbols_from_s_n(s_n_est);

end
%------------- END OF CODE --------------

function [ s_n ] = compute_s_n_from_symbols( theta )
% compute_s_n_from_symbols - compute s[n] (OFDM signal's samples) from the symbols a_k by IFFT                                 
%
% Syntax:  [ s_n ] = compute_s_n_from_symbols( theta )
%
% Inputs:
%    theta              - detected symbols, namely "hard-estimates" (valid symbols on the constellation)
%
% Outputs:
%    s_n                - estimated time-domain OFDM signal
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------

global time_shift_compensation;

N = length(theta);
s_n = sqrt(N)*ifft(theta.*((time_shift_compensation.')'));

end
%------------- END OF CODE --------------

function [ z_n ] = detect_indicators( s_n )
% compute_s_n_from_symbols - Detect the indicators defined by:
%         -
%        | 1    x[n]  > -M
%   z[n]=| 
%        | 2    x[n]  <  -M
%         -
% from the current s[n].
%
% Syntax:  [ z_n ] = detect_indicators( s_n )
%
% Inputs:
%    s_n              - time-domain OFDM signal
%
% Outputs:
%    z_n              - estimated indicator series as defined above
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------

global M;

z_n = zeros(1,length(s_n));

indices_for_1 = find(s_n>=-M);
indices_for_2 = find(s_n<-M);
z_n(indices_for_1) = 1;
z_n(indices_for_2) = 2;

end
%------------- END OF CODE --------------

function [ theta, theta_est, Q_factor ] = detect_symbols_from_s_n( s_n )
% detect_symbols_from_s_n - detect OFDM symbols from the time-doamin signal:
%       1. Compute symbols estimators (theta_est) via FFT of s[n] (OFDM signal)
%       2. Detect symbols (theta) from estimators, using the hermitian symmetry
%
% Syntax:  [ theta, theta_est, Q_factor ] = detect_symbols_from_s_n( s_n )
%
% Inputs:
%    s_n                - time-domain OFDM signal (N-dimensional vector)
%
% Outputs:
%    theta              - detected symbols, namely "hard-estimates" (valid symbols on the constellation)
%    theta_est          - "soft-estimates" (not necessarily valid symbols on the constellation)
%    Q_factor           - scalar quality measure, the mean squared error
%                         between the hard-estimates and the soft-estimates
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: readmeISEA.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------
global PSK;
global PSK_matrix;
global QAM;
global QAM_matrix;
global Constellation_code;
global time_shift_compensation;

N = length(s_n);
theta_est = (1/sqrt(N))*fft(s_n).*time_shift_compensation;
theta_est_1 = theta_est(2:N/2);
theta_est_2 = fliplr(conj(theta_est(N/2+2:N)));
theta_est_improved = (theta_est_1+theta_est_2)/2;
if ( Constellation_code==1 )
    theta_est_matrix = repmat(theta_est_improved,length(PSK),1);
    euclid_dist = (PSK_matrix(1:size(theta_est_matrix,1),1:size(theta_est_matrix,2))-theta_est_matrix).^2;
    [~, decision_index] = min(euclid_dist);
    theta_one_sided = PSK(decision_index');
else 
    theta_est_matrix = repmat(theta_est_improved,length(QAM),1);
    euclid_dist = (QAM_matrix(1:size(theta_est_matrix,1),1:size(theta_est_matrix,2))-theta_est_matrix).^2;
    [~, decision_index] = min(euclid_dist);
    theta_one_sided = QAM(decision_index');
end
theta = [0 theta_one_sided 0 fliplr(conj(theta_one_sided))];
Q_factor = mean(abs(theta-theta_est).^2);
end
%------------- END OF CODE --------------