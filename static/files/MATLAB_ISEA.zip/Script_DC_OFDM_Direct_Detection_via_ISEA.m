% Script - Demonstration of the Iterative Sign Estimation Algorithm (ISEA)
%          for Detection of OFDM symbols from a noisy signal
%
% Other m-files required: ISEA.m
%
% Subfunctions: QAM8RECT, reconstruction_real_OFDM_signal, detect_symbols_from_s_n
% MAT-files required: none
%
% References:
%	     [1] "Iterative Symbol Recovery for Power Efficient DC Biased Optical OFDM Systems",
%		      Weiss, A., Yeredor, A., Shtaif, M.,
%			  Journal of Lightwave Technology, vol. 34, no. 9, pp. 2331-2338, May 2016.
%
% See also: readmeISEA.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------

close all;
clear all;
clc;

% Define global parameters
global PSK;
global PSK_matrix;
global QAM;
global QAM_matrix;
global Constellation_code;
global time_shift_compensation;
global M;

% GUI for input paramaters from the sser
prompt = {'\fontsize{13}\fontname{Serif}Enter Constelaltion Size (Power of 2)'...
    ,'\fontsize{13}\fontname{Serif}Enter Size of Block (FFT, power of 2)'...
    ,'\fontsize{13}\fontname{Serif}Enter Signal Power'...
    ,'\fontsize{13}\fontname{Serif}Enter Noise Power'...
    ,'\fontsize{13}\fontname{Serif}Enter Time Shift (integer from [0,9])'...
    ,'\fontsize{13}\fontname{Serif}Enter \kappa (DC-bias related ratio)'};
dlg_title = 'Simulation Parameters';
num_lines = [1 70; 1 70; 1 70; 1 70; 1 70; 1 70];
def = {'8','1024','1','0.01','0','1.3'};
opts.Interpreter = 'tex';
answer = inputdlg(prompt,dlg_title,num_lines,def,opts);
num_of_symbols = str2double(answer{1});
N = str2double(answer{2});
Ps = str2double(answer{3});
Pv = str2double(answer{4});
time_shift = str2double(answer{5});
M = str2double(answer{6})*sqrt(Ps);

% Set the constellation
UIControl_FontSize_bak = get(0, 'DefaultUIControlFontSize');
set(0, 'DefaultUIControlFontSize', 13);
Constellation_code = menu('Choose Constellation Diagram:','PSK','QAM');
set(0, 'DefaultUIControlFontSize', UIControl_FontSize_bak);
if ( Constellation_code==1 )
    r = sqrt(Ps);
    PSK = pskmod((0:(num_of_symbols-1)),num_of_symbols)*r;
    PSK_matrix = repmat(transp(PSK),1,N/2);
else
    if (num_of_symbols==8)
        QAM = QAM8RECT();
    else
        QAM = qammod((0:(num_of_symbols-1)),num_of_symbols);
    end
    avg_rms = sqrt((1/num_of_symbols)*(sum(abs(QAM).^2)));
    QAM = (sqrt(Ps)/avg_rms)*QAM;
    QAM_matrix = repmat(transp(QAM),1,N/2);
end

% Draw the symbols
random_index = randi(num_of_symbols,1,N/2);
% random_index = randi(num_of_symbols,1,N);
if ( Constellation_code==1 )
    a_k = PSK(random_index(1:N/2-1));
else
    a_k = QAM(random_index(1:N/2-1));
end

a_k = [0 a_k 0 fliplr(conj(a_k))];

% compute the OFDM signal
s_n = (sqrt(N))*ifft(a_k);
t = linspace(0,N,10*N+1);
dt=t(2)-t(1);
T = max(t) - min(t);
t = t(1:(length(t)-1));
s_t = reconstruction_real_OFDM_signal(s_n,N,T,dt);

k = 0:(N-1);
time_shift_compensation = exp((-1i*2*pi*k*(time_shift*dt))/T);

% Draw AWGN
v_t = sqrt(Pv)*randn(1,length(t));
r_t_biased = s_t+M;
% Pass the signal through AWGN channel (Baseband signal)
r_t = abs(r_t_biased);
% r_t is now no longer bandlimited
y_t = r_t + v_t;
% sample the signal
y_n = downsample(y_t((1+time_shift):length(y_t)),10);

% Clipping
clipper = r_t_biased>0;
r_t_clipped = r_t_biased.*clipper;
y_t_clipped = r_t_clipped + v_t;
% sample the signal
y_n_clipped = downsample(y_t_clipped((1+time_shift):length(y_t_clipped)),10);
s_n_clipped = y_n_clipped-M;
[theta_clipped, theta_clipped_est] = detect_symbols_from_s_n(s_n_clipped);

% Compute arbitrarily initial guesse from the measurements
s_n0 = real(y_n)-M;
[theta0, theta0_est] = detect_symbols_from_s_n(s_n0);
theta0(1) = 0;
theta0(N/2+1) = 0;
% Operate ISEA for detection
tic
[theta, theta_est, Q_factor, num_of_iter, s_n] = ISEA(y_n);
toc

% Count initial guesse errors
e0 = sum(a_k(2:N/2)~=theta0(2:N/2));
% compute initial SER
SER0 = e0/(N/2-1);
% Count final decision errors
e = sum(a_k(2:N/2)~=theta(2:N/2));
% compute final SER
SER = e/(N/2-1);

% Clipping
% Count final decision errors
e_clip = sum(a_k(2:N/2)~=theta_clipped(2:N/2));
% compute final SER
SER_clip = e_clip/(N/2-1);


% plot initial guesse estimators
limit = 2*sqrt(Ps);
figure('units','normalized','outerposition',[0.15 0.15 0.7 0.7])
plot(real(theta0_est(2:N/2)),imag(theta0_est(2:N/2)),'b*','Linewidth',2);
grid;
axis([-limit limit -limit limit]);
axis square;
title(['Initial Guesse Estimators, $\textrm{SER}_0=',num2str(SER0),'$'],'Interpreter','latex');
xlabel('$\Re\{a_k\}$','Interpreter','latex'); ylabel('$\Im\{a_k\}$','Interpreter','latex');
set(gca,'FontName','CMU Serif');
set(gca,'FontSize',15);
% plot estimators
max_val2 = max(abs(theta_est));
figure('units','normalized','outerposition',[0.15 0.15 0.7 0.7])
plot(real(theta_est(2:N/2)),imag(theta_est(2:N/2)),'r*','Linewidth',2);
grid;
axis([-limit limit -limit limit]);
axis square;
title(['\textbf{ISEA} Symbols Estimators, $\textrm{SER}=',num2str(SER),'$, $P_{\textrm{noise}}=',num2str(Pv),'$, \#Iterations$=',num2str(num_of_iter),'$'],'Interpreter','latex');
xlabel('$\Re\{a_k\}$','Interpreter','latex'); ylabel('$\Im\{a_k\}$','Interpreter','latex');
set(gca,'FontName','CMU Serif');
set(gca,'FontSize',15);
% clipped
max_val3 = max(abs(theta_clipped_est));
limit3 = limit;
figure('units','normalized','outerposition',[0.15 0.15 0.7 0.7])
plot(real(theta_clipped_est(2:N/2)),imag(theta_clipped_est(2:N/2)),'g*','Linewidth',2);
grid;
axis([-limit3 limit3 -limit3 limit3]);
axis square;
title(['\textbf{Clipping} Symbols Estimators, $\textrm{SER}=',num2str(SER_clip),'$, $P_{\textrm{noise}}=',num2str(Pv),'$'],'Interpreter','latex');
xlabel('$\Re\{a_k\}$','Interpreter','latex'); ylabel('$\Im\{a_k\}$','Interpreter','latex');
set(gca,'FontName','CMU Serif');
set(gca,'FontSize',15);
%------------- END OF CODE --------------

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%------------ LOCAL FUNCTIONS -----------%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [ QAM8 ] = QAM8RECT( )
% QAM8RECT - create 8QAM rectangular constellation from BPSK/2QAM                                  
%
% Syntax:  [ QAM8 ] = QAM8RECT( )
%
% Inputs:
%    None
%
% Outputs:
%    QAM8                      - 8QAM rectangular constellation
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------
QAM2 = qammod((0:(2-1)),2);
upper_symbols = [1i*abs(QAM2(1))+QAM2(1) 1i*abs(QAM2(1)) 1i*abs(QAM2(1))+QAM2(2)];
lower_symbols = [-1i*abs(QAM2(1))+QAM2(1) -1i*abs(QAM2(1)) -1i*abs(QAM2(1))+QAM2(2)];
QAM8 = [upper_symbols QAM2 lower_symbols];
end
%------------- END OF CODE --------------

function [ s_t ] = reconstruction_real_OFDM_signal( s_n,N,T,dt )
% QAM8RECT - create an upsampled version of the OFDM signal                                 
%
% Syntax:  [ s_t ] = reconstruction_real_OFDM_signal( s_n,N,T,dt )
%
% Inputs:
%    s_n                       - samples of the OFDM signal (IFFF of the symbols)
%    N                         - FFT block size
%    T                         - Time interval
%    dt                        - desired time resolution
%
% Outputs:
%    s_t                      - reconstructed time-domain OFDM signal
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------
Ts = T/N;
upsampling_factor = round(Ts/dt);
s_n_upsampled = upsample(s_n,upsampling_factor);
S_w = fftshift(fft(s_n_upsampled));
H_w = zeros(1,length(S_w));
H_w((length(S_w)/2-N/2+1):(length(S_w)/2+N/2)) = ones(1,N);
S_w_filtered = S_w.*H_w;
s_t = upsampling_factor*ifft(fftshift(S_w_filtered));
s_t = real(s_t);
end
%------------- END OF CODE --------------

function [ theta, theta_est, Q_factor ] = detect_symbols_from_s_n( s_n )
% detect_symbols_from_s_n - detect OFDM symbols from the time-doamin signal:
%       1. Compute symbols estimators (theta_est) via FFT of s[n] (OFDM signal)
%       2. Detect symbols (theta) from estimators, using the hermitian symmetry
%
% Syntax:  [ theta, theta_est, Q_factor ] = detect_symbols_from_s_n( s_n )
%
% Inputs:
%    s_n                - time-domain OFDM signal (N-dimensional vector)
%
% Outputs:
%    theta              - detected symbols, namely "hard-estimates" (valid symbols on the constellation)
%    theta_est          - "soft-estimates" (not necessarily valid symbols on the constellation)
%    Q_factor           - scalar quality measure, the mean squared error
%                         between the hard-estimates and the soft-estimates
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: readmeISEA.pdf for more information about this MATLAB package
% Author: Amir Weiss
% email: amirweiss15@gmail.com
% Website: http://www.weissamir.com
% Oct. 2020; Last revision: 12-Oct-2020
%------------- BEGIN CODE --------------
global PSK;
global PSK_matrix;
global QAM;
global QAM_matrix;
global Constellation_code;
global time_shift_compensation;

N = length(s_n);
theta_est = (1/sqrt(N))*fft(s_n).*time_shift_compensation;
theta_est_1 = theta_est(2:N/2);
theta_est_2 = fliplr(conj(theta_est(N/2+2:N)));
theta_est_improved = (theta_est_1+theta_est_2)/2;
if ( Constellation_code==1 )
    theta_est_matrix = repmat(theta_est_improved,length(PSK),1);
    euclid_dist = (PSK_matrix(1:size(theta_est_matrix,1),1:size(theta_est_matrix,2))-theta_est_matrix).^2;
    [~, decision_index] = min(euclid_dist);
    theta_one_sided = PSK(decision_index');
else 
    theta_est_matrix = repmat(theta_est_improved,length(QAM),1);
    euclid_dist = (QAM_matrix(1:size(theta_est_matrix,1),1:size(theta_est_matrix,2))-theta_est_matrix).^2;
    [~, decision_index] = min(euclid_dist);
    theta_one_sided = QAM(decision_index');
end
theta = [0 theta_one_sided 0 fliplr(conj(theta_one_sided))];
Q_factor = mean(abs(theta-theta_est).^2);
end
%------------- END OF CODE --------------